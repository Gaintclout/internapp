FastTrack Task1: Complete Jarvis project.
