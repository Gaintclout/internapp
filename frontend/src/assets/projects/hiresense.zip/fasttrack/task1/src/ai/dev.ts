import { config } from 'dotenv';
config();

import '@/ai/flows/skills-matcher.ts';