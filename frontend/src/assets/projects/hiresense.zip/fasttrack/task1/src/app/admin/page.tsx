import AdminDashboard from "@/components/admin-dashboard";

export default function AdminPage() {
  return (
    <div className="container mx-auto py-12 px-4">
       <div className="flex flex-col items-center text-center mb-10">
        <h1 className="font-headline text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
          Admin Dashboard
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Review and manage all applicant submissions.
        </p>
      </div>
      <AdminDashboard />
    </div>
  );
}
