'use server';

import { skillsMatcher } from '@/ai/flows/skills-matcher';

const REQUIRED_SKILLS = ['python', 'react', 'sql'];

export async function getSkillsMatch(resumeDataUrl: string) {
  if (!resumeDataUrl) {
    return { success: false, error: 'Resume is empty. Please provide a valid resume.' };
  }
  try {
    const result = await skillsMatcher({
      resumeDataUrl,
      requiredSkills: REQUIRED_SKILLS,
    });
    return { success: true, data: { ...result, missingSkills: result.missingSkills.join(', ') } };
  } catch (error) {
    console.error('Error in getSkillsMatch:', error);
    return { success: false, error: 'Failed to process resume with AI.' };
  }
}
