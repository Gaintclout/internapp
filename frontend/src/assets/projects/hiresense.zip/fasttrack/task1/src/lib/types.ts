export interface Applicant {
  id: string;
  name: string;
  email: string;
  resumeUrl: string;
  skillsMatchPercentage: number;
  missingSkills: string;
  status: 'Pending' | 'Shortlisted' | 'Rejected';
}
