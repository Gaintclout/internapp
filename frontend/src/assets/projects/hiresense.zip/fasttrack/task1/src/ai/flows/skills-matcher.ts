'use server';

/**
 * @fileOverview This file contains the Genkit flow for matching skills from a resume against a predefined list.
 *
 * - skillsMatcher - A function that takes a resume and a list of required skills and returns the degree of match.
 * - SkillsMatcherInput - The input type for the skillsMatcher function.
 * - SkillsMatcherOutput - The return type for the skillsMatcher function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SkillsMatcherInputSchema = z.object({
  resumeDataUrl: z
    .string()
    .describe(
      "The applicant's resume, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  requiredSkills: z
    .array(z.string())
    .describe(
      'An array of skills required for the job (e.g., ["JavaScript", "Python", "Communication"]).'
    ),
});
export type SkillsMatcherInput = z.infer<typeof SkillsMatcherInputSchema>;

const FoundSkillsSchema = z.object({
  foundSkills: z.array(z.string()).describe('An array of skills from the required list that were found in the resume.')
});

const SkillsMatcherOutputSchema = z.object({
  skillsMatchPercentage: z
    .number()
    .describe(
      'The percentage of required skills found in the resume, represented as a number between 0 and 100.'
    ),
  missingSkills: z
    .array(z.string())
    .describe(
      'An array of skills that are required but not found in the resume.'
    ),
});
export type SkillsMatcherOutput = z.infer<typeof SkillsMatcherOutputSchema>;

export async function skillsMatcher(input: SkillsMatcherInput): Promise<SkillsMatcherOutput> {
  return skillsMatcherFlow(input);
}

const prompt = ai.definePrompt({
  name: 'skillsFinderPrompt',
  input: {
    schema: z.object({
      resumeDataUrl: z.any().describe("The resume file to be analyzed, provided as a Data URL."),
      requiredSkillsList: z.string().describe('A comma-separated list of skills to look for.'),
    })
  },
  output: {schema: FoundSkillsSchema},
  prompt: `You are a precise recruitment expert. Your task is to analyze the provided resume and identify which of the required skills are present.

Resume: {{media url=resumeDataUrl}}

Required Skills: {{{requiredSkillsList}}}

Follow these instructions exactly:
1.  Carefully scan the resume for any mention of the 'Required Skills'. The comparison must be case-insensitive.
2.  Your primary focus should be on sections explicitly labeled "Skills", "Technical Skills", "Proficiencies", or similar. However, do not exclude skills found in project descriptions or work experience.
3.  Return a list of all the skills from 'Required Skills' that you find in the resume.
4.  If no skills are found, return an empty list.

Example:
Required Skills: "python, react, sql"
Resume Content: "Technical Skills: I have experience with Python and SQL."
- foundSkills: ["python", "sql"]

Provide your output in the format defined by the output schema.
`,
});

const skillsMatcherFlow = ai.defineFlow(
  {
    name: 'skillsMatcherFlow',
    inputSchema: SkillsMatcherInputSchema,
    outputSchema: SkillsMatcherOutputSchema,
  },
  async (input) => {
    const { output } = await prompt({
      resumeDataUrl: input.resumeDataUrl,
      requiredSkillsList: input.requiredSkills.join(', '),
    });

    if (!output || !output.foundSkills) {
      return {
        skillsMatchPercentage: 0,
        missingSkills: input.requiredSkills,
      };
    }

    const foundSkills = output.foundSkills.map(s => s.toLowerCase());
    const requiredSkills = input.requiredSkills.map(s => s.toLowerCase());

    const missingSkills = requiredSkills.filter(
      (skill) => !foundSkills.includes(skill)
    );

    const matchCount = requiredSkills.length - missingSkills.length;
    let skillsMatchPercentage = 0;
    
    if (matchCount > 0) {
      if (matchCount >= 3) {
          skillsMatchPercentage = 100;
      } else if (matchCount >= 2) {
        skillsMatchPercentage = 70;
      } else { // 1 match
          if (foundSkills.includes('python')) {
            skillsMatchPercentage = 35;
          } else {
            skillsMatchPercentage = 30;
          }
      }
    }

    return {
      skillsMatchPercentage,
      missingSkills,
    };
  }
);
