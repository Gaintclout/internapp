'use client';

import { useEffect, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  useEffect(() => {
    if (!isClient) {
      return;
    }
    try {
      const isAuthenticated = sessionStorage.getItem('isAdminAuthenticated');
      if (!isAuthenticated && pathname !== '/admin/login') {
        router.replace('/admin/login');
      } else if (isAuthenticated && pathname === '/admin/login') {
        router.replace('/admin');
      }
    } catch (error) {
      // sessionStorage is not available on the server
      if (pathname !== '/admin/login') {
         router.replace('/admin/login');
      }
    }
  }, [pathname, router, isClient]);
  
  if (!isClient && pathname !== '/admin/login') {
    return null; // Or a loading spinner
  }

  return <>{children}</>;
}
