'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Loader2 } from 'lucide-react';

import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { getSkillsMatch } from '@/app/actions';
import type { Applicant } from '@/lib/types';

const formSchema = z.object({
  name: z.string().min(2, { message: 'Name must be at least 2 characters.' }),
  email: z.string().email({ message: 'Please enter a valid email address.' }),
  resume: z.custom<FileList>().refine((files) => files?.length > 0, 'Resume is required.'),
});

export default function ApplicantForm() {
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      email: '',
    },
  });
  
  const readFileAsDataURL = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setIsLoading(true);
    setIsSuccess(false);

    try {
      const resumeFile = values.resume[0];
      const resumeDataUrl = await readFileAsDataURL(resumeFile);
      
      const aiResult = await getSkillsMatch(resumeDataUrl);

      if (!aiResult.success || !aiResult.data) {
        throw new Error(aiResult.error || 'Failed to get skills match.');
      }
      
      const newApplicant: Applicant = {
        id: new Date().toISOString(),
        name: values.name,
        email: values.email,
        resumeUrl: resumeDataUrl,
        skillsMatchPercentage: aiResult.data.skillsMatchPercentage,
        missingSkills: aiResult.data.missingSkills,
        status: 'Pending',
      };
      
      try {
        const existingApplicants: Applicant[] = JSON.parse(localStorage.getItem('applicants') || '[]');
        localStorage.setItem('applicants', JSON.stringify([...existingApplicants, newApplicant]));
      } catch (error) {
        console.warn('Could not save to localStorage', error);
      }

      setIsSuccess(true);
      form.reset();
      
    } catch (error) {
      console.error(error);
      toast({
        variant: 'destructive',
        title: 'An error occurred.',
        description: error instanceof Error ? error.message : 'Please try again later.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="border-2 border-primary/20 shadow-lg">
      <CardHeader>
        <CardTitle className="font-headline text-2xl text-center">Applicant Details</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl>
                    <Input placeholder="John Doe" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email Address</FormLabel>
                  <FormControl>
                    <Input placeholder="john.doe@example.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="resume"
              render={({ field: { onChange, value, ...rest } }) => (
                <FormItem>
                  <FormLabel>Resume</FormLabel>
                  <FormControl>
                    <Input type="file" accept=".pdf,.doc,.docx,.txt,.md" onChange={(e) => onChange(e.target.files)} {...rest} />
                  </FormControl>
                  <FormDescription>
                    Upload your resume (.pdf, .doc, .docx, .txt).
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            {isSuccess && (
              <div className="p-3 text-center bg-green-100 text-green-800 border border-green-300 rounded-md">
                Application submitted successfully! You can review it in the Admin panel.
              </div>
            )}
            <Button type="submit" className="w-full bg-accent hover:bg-accent/90 text-accent-foreground" disabled={isLoading}>
              {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 'Submit Application'}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
