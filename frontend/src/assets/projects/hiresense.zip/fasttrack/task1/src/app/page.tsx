import ApplicantFormLoader from '@/components/applicant-form-loader';

export default function Home() {
  return (
    <div className="container mx-auto max-w-2xl py-12 px-4">
      <div className="flex flex-col items-center text-center mb-10">
        <h1 className="font-headline text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
          Apply for Your Dream Job
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Fill out the form below to submit your application. Our AI will rank your resume instantly.
        </p>
      </div>
      <ApplicantFormLoader />
    </div>
  );
}
