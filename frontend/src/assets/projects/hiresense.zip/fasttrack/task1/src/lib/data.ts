// This file is intentionally blank. Data persistence is handled by client-side local storage.
