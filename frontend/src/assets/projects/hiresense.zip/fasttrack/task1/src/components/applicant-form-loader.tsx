'use client';

import dynamic from 'next/dynamic';
import { Skeleton } from '@/components/ui/skeleton';

const ApplicantForm = dynamic(() => import('@/app/applicant-form'), {
  ssr: false,
  loading: () => <Skeleton className="h-[480px] w-full" />,
});

export default function ApplicantFormLoader() {
  return <ApplicantForm />;
}
