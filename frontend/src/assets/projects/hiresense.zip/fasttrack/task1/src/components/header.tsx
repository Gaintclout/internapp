'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Bot } from 'lucide-react';

import { cn } from '@/lib/utils';
import { Button } from './ui/button';

export default function Header() {
  const pathname = usePathname();

  const navItems = [
    { href: '/', label: 'Applicant' },
    { href: '/admin', label: 'Admin' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <div className="mr-4 flex items-center">
          <Link href="/" className="mr-6 flex items-center space-x-2">
            <Bot className="h-6 w-6 text-primary" />
            <span className="font-bold font-headline sm:inline-block">gaint</span>
          </Link>
        </div>
        <div className="flex flex-1 items-center justify-end space-x-2">
           <nav className="flex items-center space-x-2">
             {navItems.map((item) => (
               <Button key={item.href} asChild variant="ghost" className={cn(
                 pathname === item.href && "bg-accent text-accent-foreground"
               )}>
                 <Link href={item.href}>
                   {item.label}
                 </Link>
               </Button>
             ))}
           </nav>
        </div>
      </div>
    </header>
  );
}
