from pydantic_settings import BaseSettings
from typing import Optional
from pydantic import Field 

class Settings(BaseSettings):
    DATABASE_URL: str = "postgresql+psycopg2://postgres:Clout%23123@localhost:5432/interns"
    
    JWT_SECRET: str = "changeme"
    JWT_ALG: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    JUDGE0_BASE: str = "https://judge0-ce.p.rapidapi.com"
    JUDGE0_KEY: str = "649850c0ebmshecc75bed8229d02p100b9bjsnc75b1e041ea0"
    JUDGE0_RAPIDAPI: bool =False

    STORAGE_BUCKET: str = "internapp"

    UPI_ID: str = "gaint@upi"
    QR_IMAGE_URL: str = ""

    DEBUG: bool = False

    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
