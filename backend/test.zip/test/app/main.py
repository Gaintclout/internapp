# app/main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.db.session import init_db
from app.routers import auth, students, projects, payments, tasks, submissions, certificates, admin, mentors
from app.routers import project_auto_split, fortnight_feedback, chatbot, debug
from app.routers import oauth_login
from app.services.reports_pdf import generate_fortnight_pdf
from fastapi.openapi.utils import get_openapi

app = FastAPI(debug=True, title="Interns App Backend", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(auth.router)
app.include_router(students.router)
app.include_router(projects.router)
app.include_router(tasks.router)
app.include_router(submissions.router)
app.include_router(payments.router)
app.include_router(certificates.router)
app.include_router(admin.router)
app.include_router(mentors.router)
app.include_router(project_auto_split.router)
app.include_router(fortnight_feedback.router)
app.include_router(chatbot.router)
app.include_router(oauth_login.router)
app.include_router(debug.router)

# --- Custom OpenAPI to expose three separate OAuth2 password flows ---
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        routes=app.routes,
    )

    # Ensure components exist
    openapi_schema.setdefault("components", {})
    openapi_schema["components"].setdefault("securitySchemes", {})

    # Overwrite/add explicitly named OAuth2 password flows
    openapi_schema["components"]["securitySchemes"].update({
        "OAuth2_user": {
            "type": "oauth2",
            "flows": {
                "password": {
                    "tokenUrl": "/auth/login",
                    "scopes": {}
                }
            }
        },
        "OAuth2_mentor": {
            "type": "oauth2",
            "flows": {
                "password": {
                    "tokenUrl": "/auth/login-mentor",
                    "scopes": {}
                }
            }
        },
        "OAuth2_admin": {
            "type": "oauth2",
            "flows": {
                "password": {
                    "tokenUrl": "/auth/login-admin",
                    "scopes": {}
                }
            }
        },
    })

    app.openapi_schema = openapi_schema
    return app.openapi_schema

# attach it
app.openapi = custom_openapi
# -------------------------------------------------------------------

@app.on_event("startup")
def on_startup():
    init_db()

@app.get("/health")
def health():
    return {"status": "ok"}
