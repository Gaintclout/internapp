from sqlalchemy import Column, String, Integer, Boolean, Text, ForeignKey, DateTime, Enum as SQLEnum
from sqlalchemy.orm import relationship
from app.db.session import Base
from app.db.models.user import UUIDCol
from datetime import datetime
from enum import Enum as PyEnum

# If you use PostgreSQL UUID type in your project, keep your existing UUIDType/UUIDCol helpers.
# Example: id = UUIDCol()
class TaskState(PyEnum):
    locked = "locked"
    in_progress = "in_progress"
    passed = "passed"
    failed = "failed"

class StudentTaskStatus(Base):
    __tablename__ = "student_task_status"

    id = UUIDCol()
    student_id = Column(UUIDCol().type if hasattr(UUIDCol, "__call__") else UUIDCol, ForeignKey("students.id"))
    task_id = Column(UUIDCol().type if hasattr(UUIDCol, "__call__") else UUIDCol, ForeignKey("project_tasks.id"))
 # If you want DB-level enum:
    status = Column(SQLEnum(TaskState, name="task_state"), nullable=True)
   # or use your TaskState enum column type
    # --- tracking & progress fields ---
    attempts = Column(Integer, default=0)                       # generic submission attempts
    last_submission_id = Column(UUIDCol().type if hasattr(UUIDCol, "__call__") else UUIDCol, ForeignKey("submissions.id"), nullable=True)
    unlocked_at = Column(DateTime, nullable=True)
    passed_at = Column(DateTime, nullable=True)

    # Hidden test + auto-override tracking (per-student)
    hidden_attempts = Column(Integer, default=0)
    first_hidden_attempt_at = Column(DateTime, nullable=True)
    mentor_override = Column(Boolean, default=False)
    mentor_override_by = Column(Integer, nullable=True)
    mentor_override_at = Column(DateTime, nullable=True)
    mentor_override_note = Column(Text, nullable=True)

    # Per-student progress percent (0..100)
    progress_percent = Column(Integer, default=0)

  
