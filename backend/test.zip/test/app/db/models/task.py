from sqlalchemy import Column, String, Integer, Boolean, Text, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.sqlite import JSON
from app.db.session import Base
from app.db.models.user import UUIDCol
from datetime import datetime

# UUID type helper
try:
    from sqlalchemy.dialects.postgresql import UUID as PGUUID
    UUIDType = PGUUID(as_uuid=True)
except Exception:
    from sqlalchemy.types import CHAR
    UUIDType = CHAR(36)

try:
    from sqlalchemy.dialects.postgresql import JSONB
    JSONType = JSONB
except Exception:
    JSONType = JSON


class ProjectTask(Base):
    __tablename__ = "project_tasks"

    id = UUIDCol()
    project_id = Column(UUIDType, ForeignKey("projects.id"))
    seq = Column(Integer, nullable=False)                     # sequence/order inside project
    title = Column(String, nullable=False)
    description_md = Column(Text, nullable=True)
    judge0_language_id = Column(Integer, nullable=True)
    starter_code_url = Column(Text, nullable=True)
    hidden_tests = Column(JSONType, nullable=True)            # [{"stdin":"", "expected":""}]
    visible_tests = Column(JSONType, nullable=True)
    max_attempts = Column(Integer, nullable=True)
    is_learning_task = Column(Boolean, default=False)

    # Template-level workflow metadata (OPTIONAL — per-student progress should still be in StudentTaskStatus)
    #locked = Column(Boolean, default=True)                    # whether this template task is locked globally
    unlocked_at = Column(DateTime, nullable=True)             # when the template was unlocked
    completed = Column(Boolean, default=False)                # template-level completed flag (rarely used)
    progress_percent = Column(Integer, default=0)             # template-level progress summary (optional)

    project = relationship("Project", back_populates="tasks")
