from sqlalchemy import Column, String, Boolean, Text
from sqlalchemy.orm import relationship
from app.db.session import Base
from app.db.models.user import UUIDCol

class Project(Base):
    __tablename__ = "projects"
    id = UUIDCol()
    title = Column(String, nullable=False)
    technology = Column(String, nullable=True)
    description_md = Column(Text, nullable=True)
    doc_pdf_url = Column(Text, nullable=True)
    doc_docx_url = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True)

    tasks = relationship("ProjectTask", back_populates="project", cascade="all, delete-orphan")
    students = relationship("Student", back_populates="project")
