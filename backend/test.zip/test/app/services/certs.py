from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from io import BytesIO
import os
from datetime import date
from sqlalchemy.orm import Session
from app.db.models.student import Student
from app.db.models.project import Project

def render_and_store_certificate(db: Session, st: Student) -> str:
    # simple PDF in-memory
    buff = BytesIO()
    c = canvas.Canvas(buff, pagesize=A4)
    width, height = A4
    c.setFont("Helvetica-Bold", 20)
    c.drawCentredString(width/2, height-100, "Internship Completion Certificate")
    c.setFont("Helvetica", 12)
    proj_title = (st.project.title if st.project else "Project")
    line = f"This certifies that {st.user.name} from {st.user.college_name or ''}"
    c.drawCentredString(width/2, height-140, line)
    line2 = f"has successfully completed the {st.internship_type.value if st.internship_type else 'Internship'} on '{proj_title}'"
    c.drawCentredString(width/2, height-160, line2)
    c.drawCentredString(width/2, height-180, f"Date: {date.today().strftime('%d/%m/%Y')}")
    c.showPage()
    c.save()
    data = buff.getvalue()

    out_dir = "/mnt/data/certificates"
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{st.id}.pdf")
    with open(path, "wb") as f:
        f.write(data)
    return f"sandbox:{path}"
