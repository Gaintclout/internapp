from datetime import timedelta, date, datetime
from sqlalchemy.orm import Session
from app.db.models.student import Student, InternshipType
from app.db.models.task import ProjectTask
from app.db.models.student_task_status import StudentTaskStatus, TaskState

def within_learning_window(start: date, internship_type: InternshipType) -> bool:
    if internship_type == InternshipType.days45:
        return (date.today() - start).days < 10
    if internship_type == InternshipType.semester4m:
        return (date.today() - start).days < 30
    return True

def visible_tasks_for_student(db: Session, st: Student):
    tasks = db.query(ProjectTask).filter(ProjectTask.project_id == st.project_id).order_by(ProjectTask.seq.asc()).all()
    if st.internship_type == InternshipType.fasttrack:
        return [{"id": t.id, "seq": t.seq, "title": t.title, "is_learning": t.is_learning_task} for t in tasks]

    visible = []
    for t in tasks:
        sts = db.query(StudentTaskStatus).filter(StudentTaskStatus.student_id == st.id, StudentTaskStatus.task_id == t.id).first()
        if t.is_learning_task:
            if not st.project_start_date or within_learning_window(st.project_start_date, st.internship_type):
                visible.append({"id": t.id, "seq": t.seq, "title": t.title, "is_learning": True})
            else:
                visible.append({"id": t.id, "seq": t.seq, "title": t.title, "is_learning": True})
            continue
        # sequential: show until first unmet pass
        if not visible or (sts and sts.status == TaskState.passed):
            visible.append({"id": t.id, "seq": t.seq, "title": t.title, "is_learning": False})
            continue
        # find previous task's status
        prev = tasks[max(0, tasks.index(t)-1)]
        prev_sts = db.query(StudentTaskStatus).filter(StudentTaskStatus.student_id == st.id, StudentTaskStatus.task_id == prev.id).first()
        if prev_sts and prev_sts.status == TaskState.passed:
            visible.append({"id": t.id, "seq": t.seq, "title": t.title, "is_learning": False})
        else:
            break
    return visible

def mark_pass_if_all_tests_pass(results: list[dict]) -> bool:
    # Judge0: status.id == 3 => Accepted
    for r in results:
        if (r.get("status") or {}).get("id") != 3:
            return False
    return True
