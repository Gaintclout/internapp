# app/services/judge0.py
import base64
import os
import json
import time
from datetime import datetime
from typing import Any, Dict

import httpx
from app.core.config import settings

# Keep your existing create_submission/get_submission behavior (base64 encoded payload)
# This implementation adds robust header selection and clearer error messages.

DEFAULT_JUDGE0_BASE = getattr(settings, "JUDGE0_BASE", "https://judge0-ce.p.rapidapi.com")

def _build_headers() -> Dict[str, str]:
    """
    Build headers for Judge0 requests. Supports RapidAPI (X-RapidAPI-Key + X-RapidAPI-Host)
    or direct Judge0 token (X-Auth-Token). Returns headers dict.
    """
    headers: Dict[str, str]= {"Content-Type": "application/json"}
    # Prefer RapidAPI header set when configured
    if getattr(settings, "JUDGE0_RAPIDAPI", False) and getattr(settings, "JUDGE0_KEY", None):
        headers.update({
            "X-RapidAPI-Key": "649850c0ebmshecc75bed8229d02p100b9bjsnc75b1e041ea0",
            "X-RapidAPI-Host": "judge0-ce.p.rapidapi.com"
        })
    elif getattr(settings, "JUDGE0_KEY", None):
        # Direct Judge0 self-hosted / community instance token header (if used)
        headers.update({"X-Auth-Token": settings.JUDGE0_KEY})
    return headers

async def create_submission(
    source_code: str,
    language_id: int,
    stdin: str = "",
    expected_output: str | None = None
) -> Dict[str, Any]:
    """
    Submit code to Judge0. Payload fields are base64 encoded.
    Returns parsed JSON response (the initial response which may contain a token).
    Raises RuntimeError with a human-friendly message on HTTP failures.
    """
    payload: Dict[str, Any] = {
        "source_code": base64.b64encode(source_code.encode()).decode(),
        "language_id": language_id,
        "stdin": base64.b64encode(stdin.encode()).decode(),
    }
    if expected_output is not None:
        payload["expected_output"] = base64.b64encode(expected_output.encode()).decode()

    headers = _build_headers()
    base = getattr(settings, "JUDGE0_BASE", DEFAULT_JUDGE0_BASE).rstrip("/")

    try:
        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post(f"{base}/submissions?base64_encoded=true&wait=false", json=payload, headers=headers)
    except httpx.RequestError as exc:
        raise RuntimeError(f"Judge0 request failed: {exc}") from exc

    # Provide clearer error messages for auth / bad config
    if r.status_code == 401:
        raise RuntimeError("Judge0 unauthorized (401). Check JUDGE0_KEY and JUDGE0_RAPIDAPI/JUDGE0_BASE settings.")
    if r.status_code >= 400:
        # attempt to give response body if present
        body = None
        try:
            body = r.json()
        except Exception:
            body = r.text
        raise RuntimeError(f"Judge0 returned HTTP {r.status_code}: {body}")

    try:
        return r.json()
    except Exception as exc:
        raise RuntimeError(f"Judge0 returned invalid JSON response: {exc}") from exc


async def get_submission(token: str) -> Dict[str, Any]:
    """
    Poll / fetch a submission result by token.
    Raises RuntimeError on HTTP errors with helpful messages.
    """
    headers = _build_headers()
    base = getattr(settings, "JUDGE0_BASE", DEFAULT_JUDGE0_BASE).rstrip("/")

    try:
        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.get(f"{base}/submissions/{token}?base64_encoded=true", headers=headers)
    except httpx.RequestError as exc:
        raise RuntimeError(f"Judge0 request failed: {exc}") from exc

    if r.status_code == 401:
        raise RuntimeError("Judge0 unauthorized (401). Check JUDGE0_KEY and JUDGE0_RAPIDAPI/JUDGE0_BASE settings.")
    if r.status_code >= 400:
        body = None
        try:
            body = r.json()
        except Exception:
            body = r.text
        raise RuntimeError(f"Judge0 returned HTTP {r.status_code}: {body}")

    try:
        return r.json()
    except Exception as exc:
        raise RuntimeError(f"Judge0 returned invalid JSON response: {exc}") from exc


# -------------------------
# Automated evaluation + auto-override (Judge0-only runner output)
# -------------------------
MAX_HIDDEN_ATTEMPTS = int(os.getenv("MAX_HIDDEN_ATTEMPTS", getattr(settings, "MAX_HIDDEN_ATTEMPTS", 3)))
OVERRIDE_AFTER_DAYS = int(os.getenv("OVERRIDE_AFTER_DAYS", getattr(settings, "OVERRIDE_AFTER_DAYS", 7)))
OVERRIDE_PERCENT = int(os.getenv("OVERRIDE_PERCENT", getattr(settings, "OVERRIDE_PERCENT", 80)))
SYSTEM_OVERRIDE_USER_ID = int(os.getenv("SYSTEM_OVERRIDE_USER_ID", getattr(settings, "SYSTEM_OVERRIDE_USER_ID", 0)))

# NOTE: import models here to avoid circular imports in other modules
from app.db.models.student_task_status import StudentTaskStatus  # per-student progress row
from app.db.models.task import ProjectTask

async def evaluate_submission_and_maybe_override(
    db,
    sts: StudentTaskStatus,
    task: ProjectTask,
    *,
    source_code: str,
    language_id: int,
    stdin: str = ""
) -> Dict[str, Any]:
    """
    Submits source_code to Judge0 runner and decides:
      - fail_public: public tests failed (do not unlock)
      - hidden_fail: public passed but hidden failing (increment attempts)
      - auto_override: hidden failing but threshold reached -> mark passed with OVERRIDE_PERCENT and unlock next
      - complete: public+hidden passed -> mark 100% and unlock next
      - fallback uses Judge0 status id (3 often means accepted)

    Returns dict with "action" and details.
    """
    now = datetime.utcnow()

    # 1) create submission (your helper returns token or body)
    try:
        sub_resp = await create_submission(source_code=source_code, language_id=language_id, stdin=stdin)
    except RuntimeError as e:
        # bubble up with clear message so caller can return 502 / handle gracefully
        raise RuntimeError(f"Judge0 create_submission failed: {e}") from e

    token = sub_resp.get("token")
    # if token present, poll final body; otherwise create_submission returned final body
    try:
        if token:
            final_body = await get_submission(token)
        else:
            final_body = sub_resp
    except RuntimeError as e:
        raise RuntimeError(f"Judge0 get_submission failed: {e}") from e

    stdout = (final_body.get("stdout") or "").strip()

    # Try parse JSON from stdout (prefer the last non-empty line)
    parsed = None
    try:
        parsed = json.loads(stdout)
    except Exception:
        lines = [ln.strip() for ln in stdout.splitlines() if ln.strip()]
        if lines:
            try:
                parsed = json.loads(lines[-1])
            except Exception:
                parsed = None

    # If structured JSON exists, expect {"public": {"passed":X,"total":Y}, "hidden": {"passed":A,"total":B}}
    if isinstance(parsed, dict):
        public = parsed.get("public", {})
        hidden = parsed.get("hidden", {})
        p_total = int(public.get("total", 0))
        p_passed = int(public.get("passed", 0))
        h_total = int(hidden.get("total", 0))
        h_passed = int(hidden.get("passed", 0))

        if p_total > 0 and p_passed < p_total:
            # public tests failed -> increment attempts for visibility and return
            sts.attempts = (getattr(sts, "attempts", 0) or 0) + 1
            db.add(sts); db.commit()
            return {"action": "fail_public", "public_total": p_total, "public_passed": p_passed, "stdout": stdout}

        # public passed -> consider hidden
        if h_total == 0 or h_passed == h_total:
            # normal completion
            try:
                sts.status = getattr(sts, "status", "passed")
            except Exception:
                sts.status = "passed"
            if hasattr(sts, "passed_at"):
                sts.passed_at = now
            sts.hidden_attempts = 0
            sts.progress_percent = 100
            db.add(sts)

            # unlock next ProjectTask for this student
            nxt = db.query(ProjectTask).filter(
                ProjectTask.student_project_id == task.student_project_id,
                ProjectTask.order_index == task.order_index + 1
            ).first()
            if nxt:
                nxt_sts = db.query(StudentTaskStatus).filter_by(student_id=sts.student_id, task_id=nxt.id).first()
                if not nxt_sts:
                    nxt_sts = StudentTaskStatus(student_id=sts.student_id, task_id=nxt.id)
                nxt_sts.unlocked_at = now
                db.add(nxt_sts)

            db.commit()
            return {"action": "complete", "public_passed": p_passed, "hidden_passed": h_passed}

        # hidden failing -> increment hidden_attempts and maybe auto-override
        sts.hidden_attempts = (getattr(sts, "hidden_attempts", 0) or 0) + 1
        if not getattr(sts, "first_hidden_attempt_at", None):
            sts.first_hidden_attempt_at = now
        db.add(sts); db.commit()

        attempts = getattr(sts, "hidden_attempts", 0) or 0
        days_since = (now - sts.first_hidden_attempt_at).days if getattr(sts, "first_hidden_attempt_at", None) else 0
        if attempts >= MAX_HIDDEN_ATTEMPTS or days_since >= OVERRIDE_AFTER_DAYS:
            # auto-override
            sts.mentor_override = True
            sts.mentor_override_by = SYSTEM_OVERRIDE_USER_ID
            sts.mentor_override_at = now
            sts.mentor_override_note = f"Auto-override after {attempts} hidden attempts / {days_since} days"
            sts.progress_percent = OVERRIDE_PERCENT
            try:
                sts.status = getattr(sts, "status", "passed")
            except Exception:
                sts.status = "passed"
            if hasattr(sts, "passed_at"):
                sts.passed_at = now
            db.add(sts)

            # unlock next
            nxt = db.query(ProjectTask).filter(
                ProjectTask.student_project_id == task.student_project_id,
                ProjectTask.order_index == task.order_index + 1
            ).first()
            if nxt:
                nxt_sts = db.query(StudentTaskStatus).filter_by(student_id=sts.student_id, task_id=nxt.id).first()
                if not nxt_sts:
                    nxt_sts = StudentTaskStatus(student_id=sts.student_id, task_id=nxt.id)
                nxt_sts.unlocked_at = now
                db.add(nxt_sts)

            db.commit()
            return {"action": "auto_override", "attempts": attempts, "days_since": days_since}
        else:
            return {"action": "hidden_fail", "attempts": attempts, "days_since": days_since, "hidden_passed": h_passed}

    # Fallback: no structured JSON — use Judge0 status id heuristic (status.id == 3 -> accepted)
    status_id = (final_body.get("status") or {}).get("id", 0)
    if status_id == 3:
        try:
            sts.status = getattr(sts, "status", "passed")
        except Exception:
            sts.status = "passed"
        if hasattr(sts, "passed_at"):
            sts.passed_at = now
        sts.progress_percent = 100
        db.add(sts)

        nxt = db.query(ProjectTask).filter(
            ProjectTask.student_project_id == task.student_project_id,
            ProjectTask.order_index == task.order_index + 1
        ).first()
        if nxt:
            nxt_sts = db.query(StudentTaskStatus).filter_by(student_id=sts.student_id, task_id=nxt.id).first()
            if not nxt_sts:
                nxt_sts = StudentTaskStatus(student_id=sts.student_id, task_id=nxt.id)
            nxt_sts.unlocked_at = now
            db.add(nxt_sts)

        db.commit()
        return {"action": "complete_fallback", "status": status_id}

    # default failure fallback
    sts.attempts = (getattr(sts, "attempts", 0) or 0) + 1
    db.add(sts); db.commit()
    return {"action": "fail_fallback", "status": status_id, "stdout": stdout}
