# app/services/reports_pdf.py
from io import BytesIO
from datetime import datetime
from typing import List, Dict, Any

# Use reportlab to generate PDF. Install: pip install reportlab
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors

# Short mentor feedback templates (≈20 words)
FEEDBACK_TEXT = {
    "completed": "Good — task completed. Nicely done; keep following the same approach for subsequent tasks.",
    "started": "Work in progress — please complete remaining items, focus on edge cases and hidden requirements.",
    "not_started": "Not started — you must begin this task immediately. Reach out if you need clarification."
}

def _status_to_feedback_and_percent(progress_percent: int) -> tuple[str, int]:
    """
    Map progress_percent to feedback label and display percentage.
    Rules (as discussed):
      - >= 90 => completed (100%)
      - 40..89 => started/partial (50%)
      - < 40 => not started (10%)
    """
    if progress_percent >= 90:
        return FEEDBACK_TEXT["completed"], 100
    if progress_percent >= 40:
        return FEEDBACK_TEXT["started"], 50
    return FEEDBACK_TEXT["not_started"], 10

def _format_date(dt):
    if not dt:
        return ""
    if isinstance(dt, str):
        return dt
    return dt.strftime("%Y-%m-%d")

def generate_fortnight_pdf(db_session, student_id: str, from_date: datetime, to_date: datetime) -> bytes:
    """
    Generate a fortnight report PDF for a given student between from_date and to_date.

    Args:
      - db_session: SQLAlchemy Session (pass from your route dependency)
      - student_id: student's UUID / id
      - from_date, to_date: date range for the fortnight (datetime.date or datetime)

    Returns:
      - PDF bytes
    """
    # Import models here to avoid circular import at module import time
      # Import models here to avoid circular import at module import time
    from app.db.models.student import Student
    from app.db.models.project import Project
    from app.db.models.student_task_status import StudentTaskStatus

    # safe import for ProjectTask (try the common filenames)
    try:
        from app.db.models.task import ProjectTask
    except Exception:
            ProjectTask = None  # we'll detect below

    # Fetch student / project info (adjust to your schema)
    student = db_session.query(Student).filter(Student.id == student_id).first()
    if not student:
        # return HTTP 404 so client gets a friendly response
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="student not found")
      
    from app.db.models.task import ProjectTask

    if ProjectTask is None:
        # This indicates the project task model couldn't be imported; log helpful error
        raise ImportError("ProjectTask model not found: check app/db/models/task.py or project_task.py")


    # Find student tasks within the project's tasks that were unlocked/active in this range
    sts_rows = db_session.query(StudentTaskStatus).filter(
        StudentTaskStatus.student_id == student_id,
        # Optionally filter by unlocked_at or last update dates if you record them
    ).all()

    # Prepare tasks list for the report. We will include tasks that have unlocked_at or updated during period.
    tasks_for_period = []
    for s in sts_rows:
        # load task metadata
        t = db_session.query(ProjectTask).filter(ProjectTask.id == s.task_id).first()
        # check if task falls in date range (approx: check unlocked_at or passed_at)
        in_period = False
        if getattr(s, "unlocked_at", None):
            in_period = (from_date <= s.unlocked_at <= to_date) if from_date and to_date else True
        if getattr(s, "passed_at", None):
            in_period = in_period or (from_date <= s.passed_at <= to_date) if from_date and to_date else True
        # also include if last_submission_id exists (recent activity)
        if not in_period and getattr(s, "last_submission_id", None):
            in_period = True
        if not t:
            continue
        tasks_for_period.append({
            "task_title": getattr(t, "title", "Untitled"),
            "task_id": str(t.id),
            "progress_percent": getattr(s, "progress_percent", 0) or 0,
            "hidden_attempts": getattr(s, "hidden_attempts", 0) or 0,
            "status": getattr(s, "status", "unknown"),
        })

    # Build PDF with reportlab
    buff = BytesIO()
    doc = SimpleDocTemplate(buff, pagesize=A4, rightMargin=18*mm, leftMargin=18*mm, topMargin=18*mm, bottomMargin=18*mm)
    styles = getSampleStyleSheet()
    flow: List[Any] = []

    # Header
    flow.append(Paragraph(f"<b>Quincena Report</b>", styles["Title"]))
    flow.append(Spacer(1, 6))

    # Student & registration summary
    reg_html = f"""
    <b>Name:</b> {student.name if hasattr(student, 'name') else ''} <br/>
    <b>Email:</b> {student.email if hasattr(student, 'email') else ''} <br/>
    <b>College:</b> {getattr(student,'college_name','')} <br/>
    <b>College ID:</b> {getattr(student,'college_id','')} <br/>
    <b>Project ID:</b> {getattr(student,'project_id','')} <br/>
    <b>Period:</b> {from_date.strftime('%Y-%m-%d')} to {to_date.strftime('%Y-%m-%d')}
    """
    flow.append(Paragraph(reg_html, styles["Normal"]))
    flow.append(Spacer(1, 8))

    # Tasks table header & rows
    data = [["#","Task","Assigned for 15 days","Progress (%)","Mentor feedback","Marks"]]
    for i, row in enumerate(tasks_for_period, start=1):
        fb_text, marks = _status_to_feedback_and_percent(int(row["progress_percent"]))
        # keep feedback around 20 words (truncate safely)
        fb_short = " ".join(fb_text.split()[:20])
        data.append([str(i), row["task_title"], "Yes", str(row["progress_percent"]), fb_short, f"{marks}%"])

    if len(data) == 1:
        flow.append(Paragraph("No tasks found for this fortnight.", styles["Normal"]))
    else:
        tbl = Table(data, colWidths=[20*mm, 70*mm, 40*mm, 25*mm, 100*mm, 20*mm])
        tbl.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#E6E0E0")),
            ("GRID", (0,0), (-1,-1), 0.5, colors.black),
            ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
            ("ALIGN", (3,1), (3,-1), "CENTER"),
            ("ALIGN", (5,1), (5,-1), "CENTER"),
        ]))
        flow.append(tbl)

    flow.append(Spacer(1, 12))

    # Guide signature / stamp placeholder
    flow.append(Paragraph("Guide Signature: ____________________", styles["Normal"]))
    flow.append(Spacer(1, 6))
    flow.append(Paragraph("Stamp: ____________________", styles["Normal"]))

    # Build PDF
    doc.build(flow)

    pdf_bytes = buff.getvalue()
    buff.close()
    return pdf_bytes


