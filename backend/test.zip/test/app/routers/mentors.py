from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db.models.user import RoleEnum, User
from app.core.deps import require_mentor

router = APIRouter(prefix="/mentors", tags=["mentors"])

@router.get("/dashboard")
def mentor_dashboard(user: User = Depends(require_mentor), db: Session = Depends(get_db)):
    # Extend to list assigned interns/progress
    return {"message": "Mentor dashboard placeholder", "user_id": str(user.id)}
