from fastapi import APIRouter, Depends, Query, HTTPException, status
from sqlalchemy.orm import Session
from uuid import UUID
from datetime import date

from app.db.session import get_db
from app.db.models.user import User, RoleEnum
from app.db.models.student import Student
from app.db.models.project import Project
from app.db.models.payment import Payment, PaymentPurpose, PaymentStatus
from app.core.deps import get_current_user

router = APIRouter(prefix="/projects", tags=["projects"])

@router.get("/suggestions")
def suggestions(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    # Ensure project payment done
    st = db.query(Student).filter(Student.user_id == user.id).first()
    paid = db.query(Payment).filter(
        Payment.student_id == st.id,
        Payment.purpose == PaymentPurpose.project,
        Payment.status.in_([PaymentStatus.success, PaymentStatus.verified])
    ).first()
    if not paid:
        raise HTTPException(status_code=402, detail="Project payment required")

    q = db.query(Project).filter(Project.is_active == True)  # noqa: E712
    if st.preferred_language:
        q = q.filter(Project.technology.like(f"%{st.preferred_language}%"))
    items = q.limit(3).all()
    return [{"id": p.id, "title": p.title, "technology": p.technology} for p in items]

@router.post("/select")
def select_project(
    project_id: str = Query(..., description="Project UUID or project title/slug"),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    # Only students may select
    if user.role != RoleEnum.student:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Only students may select a project")

    # Load student row
    st = db.query(Student).filter(Student.user_id == user.id).first()
    if not st:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Student profile not found")

    # OPTIONAL: Ensure student paid before selecting (uncomment if required)
    # payment = (
    #     db.query(Payment)
    #       .filter(Payment.student_id == st.id,
    #               Payment.purpose == PaymentPurpose.project_fee,   # adjust enum/value
    #               Payment.status == PaymentStatus.paid)
    #       .order_by(Payment.created_at.desc())
    #       .first()
    # )
    # if not payment:
    #     raise HTTPException(status_code=status.HTTP_402_PAYMENT_REQUIRED, detail="Project selection requires payment")

    # Resolve project: try UUID first, then try title/slug fallback
    proj = None
    try:
        pid = UUID(project_id)
    except ValueError:
        # fallback: allow searching by title or slug (adjust field to your schema)
        proj = db.query(Project).filter(Project.title == project_id).first()
    else:
        proj = db.query(Project).filter(Project.id == pid).first()

    if not proj:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")

    # If the same project is already selected, return gently
    if st.project_id and str(st.project_id) == str(proj.id):
        return {"message": "Project already selected", "project_id": str(proj.id), "title": getattr(proj, "title", None)}

    # Attach project to student and set start date if missing
    st.project_id = proj.id
    if not st.project_start_date:
        st.project_start_date = date.today()

    db.add(st)
    db.commit()
    db.refresh(st)

    return {
        "message": "Project selected",
        "project_id": str(proj.id),
        "project_title": getattr(proj, "title", None),
        "project_start_date": st.project_start_date.isoformat() if st.project_start_date else None,
    }

@router.get("/materials")
def materials(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    st = db.query(Student).filter(Student.user_id == user.id).first()
    if not st or not st.project_id:
        raise HTTPException(status_code=400, detail="No project selected")
    p = db.query(Project).filter(Project.id == st.project_id).first()
    if not p:
        raise HTTPException(status_code=404, detail="Project not found")

    # safe attribute lookup in case your model uses docs_pdf_url/docs_docx_url or doc_pdf_url/doc_docx_url
    pdf = getattr(p, "docs_pdf_url", None) or getattr(p, "doc_pdf_url", None) or getattr(p, "docs_pdf", None) or getattr(p, "pdf_url", None)
    docx = getattr(p, "docs_docx_url", None) or getattr(p, "doc_docx_url", None) or getattr(p, "docx_url", None)
    return {"pdf": pdf, "docx": docx}

