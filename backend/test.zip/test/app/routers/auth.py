# app/routers/auth.py
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from typing import Optional
from passlib.exc import UnknownHashError

from app.db.session import get_db
from app.db.models.user import User, RoleEnum
from app.db.models.student import Student
from app.core.security import hash_password, verify_password, create_access_token
from app.schemas.auth import RegisterStudent, TokenOut

router = APIRouter(prefix="/auth", tags=["auth"])

# --- Fixed credentials (as requested) ---
MENTOR_FIXED_EMAIL = "rohinireddy242@gmail.com"
MENTOR_FIXED_PASSWORD = "Rohini#123"

ADMIN_FIXED_EMAIL = "gaintclout@gmail.com"
ADMIN_FIXED_PASSWORD = "Clout#123"
# ------------------------------------------------

def _ensure_user_exists(db: Session, email: str, role: RoleEnum, name: Optional[str] = None, password: Optional[str] = None) -> User:
    """
    Ensure a User row exists with the given college_email.
    If absent, create it with minimal fields and provided password (hashed).
    """
    user = db.query(User).filter(User.college_email == email).first()
    if user:
        if user.role != role:
            user.role = role
            db.add(user); db.commit(); db.refresh(user)
        return user

    user = User(
        role=role,
        name=name or role.value.capitalize(),
        college_email=email,
        phone=None,
        password_hash=hash_password(password) if password is not None else hash_password("changeMe123!"),
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    # create Student row if it's a student role (safe no-op otherwise)
    if role == RoleEnum.student:
        from app.db.models.student import Student as StudentModel
        st = db.query(StudentModel).filter_by(user_id=user.id).first()
        if not st:
            db.add(Student(user_id=user.id))
            db.commit()
    return user


@router.post("/register-student", response_model=TokenOut)
def register_student(payload: RegisterStudent, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.college_email == payload.college_email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    user = User(
        role=RoleEnum.student,
        name=payload.name,
        college_email=payload.college_email,
        phone=payload.phone,
        password_hash=hash_password(payload.password),
        college_name=payload.college_name,
        pursuing_year=payload.pursuing_year,
    )
    db.add(user)
    db.flush()
    student = Student(user_id=user.id)
    db.add(student)
    db.commit()
    token = create_access_token({"sub": str(user.id), "role": user.role})
    return TokenOut(access_token=token)


@router.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """
    OAuth2-compatible login endpoint that accepts form-data (username, password).
    This searches multiple columns in your User model and falls back to id lookup.
    """
    identifier = form_data.username
    password = form_data.password

    candidate_fields = ("email", "username", "college_email", "phone")
    user = None
    for fld in candidate_fields:
        if hasattr(User, fld):
            user = db.query(User).filter(getattr(User, fld) == identifier).first()
            if user:
                break

    if not user:
        try:
            user = db.query(User).filter(User.id == identifier).first()
        except Exception:
            user = None

    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

    pw_fields = ("password_hash", "hashed_password", "password")
    hashed = None
    hashed_field_name = None
    for p in pw_fields:
        if hasattr(user, p):
            hashed = getattr(user, p)
            hashed_field_name = p
            break

    if not hashed:
        raise HTTPException(status_code=500, detail="User record missing password field (check User model)")

    ok = False
    try:
        ok = verify_password(password, hashed)
    except UnknownHashError:
        # Stored hash not recognized by passlib. If DB contains plaintext password,
        # accept it (for migration) and replace with a proper hash.
        if hashed == password:
            new_hash = hash_password(password)
            setattr(user, hashed_field_name, new_hash)
            db.add(user)
            db.commit()
            db.refresh(user)
            ok = True
        else:
            ok = False

    if not ok:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

    access_token = create_access_token({"sub": str(user.id), "role": user.role})
    return {"access_token": access_token, "token_type": "bearer"}


# -----------------------
# Fixed mentor login
# -----------------------
@router.post("/login-mentor")
def login_mentor(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    username = form_data.username
    password = form_data.password

    if username != MENTOR_FIXED_EMAIL or password != MENTOR_FIXED_PASSWORD:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

    user = _ensure_user_exists(db, MENTOR_FIXED_EMAIL, RoleEnum.mentor, name="Mentor", password=MENTOR_FIXED_PASSWORD)
    access_token = create_access_token({"sub": str(user.id), "role": user.role})
    return {"access_token": access_token, "token_type": "bearer"}


# -----------------------
# Fixed admin login
# -----------------------
@router.post("/login-admin")
def login_admin(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    username = form_data.username
    password = form_data.password

    if username != ADMIN_FIXED_EMAIL or password != ADMIN_FIXED_PASSWORD:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

    user = _ensure_user_exists(db, ADMIN_FIXED_EMAIL, RoleEnum.admin, name="Admin", password=ADMIN_FIXED_PASSWORD)
    access_token = create_access_token({"sub": str(user.id), "role": user.role})
    return {"access_token": access_token, "token_type": "bearer"}
