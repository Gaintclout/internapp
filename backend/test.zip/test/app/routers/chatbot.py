# app/routers/chatbot.py
from fastapi import APIRouter, HTTPException, Depends
import openai, os

router = APIRouter(prefix="/chatbot", tags=["chatbot"])

openai.api_key = os.getenv("OPENAI_API_KEY")

@router.post("/ask")
async def ask_chatbot(question: str):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are an AI mentor helping internship students with project guidance."},
                {"role": "user", "content": question},
            ],
        )
        answer = response["choices"][0]["message"]["content"]
        return {"response": answer}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
