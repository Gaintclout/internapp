from fastapi import APIRouter, Depends, HTTPException, Form
from sqlalchemy.orm import Session
from datetime import datetime
import uuid
from app.db.session import get_db
from app.core.deps import get_current_user
from app.db.models.user import User, RoleEnum
from app.db.models.student import Student
from app.db.models.payment import Payment, PaymentPurpose, PaymentStatus

router = APIRouter(prefix="/payments", tags=["payments"])

@router.post("/project")
def project_payment(payment_id: str = Form(...), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role != RoleEnum.student:
        raise HTTPException(status_code=403, detail="Only students can pay")
    st = db.query(Student).filter(Student.user_id == user.id).first()
    existing = db.query(Payment).filter(Payment.student_id == st.id, Payment.purpose == PaymentPurpose.project).first()
    if existing:
        raise HTTPException(status_code=400, detail="Project payment already recorded")
    pay = Payment(
        id=str(uuid.uuid4()), student_id=st.id, purpose=PaymentPurpose.project,
        amount_inr=5999, payment_id=payment_id, status=PaymentStatus.success
    )
    db.add(pay)
    db.commit()
    return {"message": "Project payment recorded. You can now select your project."}

@router.post("/certificate")
def certificate_payment(payment_id: str = Form(...), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role != RoleEnum.student:
        raise HTTPException(status_code=403, detail="Only students can pay")
    st = db.query(Student).filter(Student.user_id == user.id).first()
    existing = db.query(Payment).filter(Payment.student_id == st.id, Payment.purpose == PaymentPurpose.certificate).first()
    if existing:
        raise HTTPException(status_code=400, detail="Certificate payment already recorded")
    pay = Payment(
        id=str(uuid.uuid4()), student_id=st.id, purpose=PaymentPurpose.certificate,
        amount_inr=1999, payment_id=payment_id, status=PaymentStatus.success
    )
    db.add(pay)
    db.commit()
    return {"message": "Certificate payment recorded. You can now download your certificate."}
