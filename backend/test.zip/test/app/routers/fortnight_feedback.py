# app/routers/fortnight_feedback.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.deps import get_current_user
from app.db.session import get_db
from app.db.models.user import User, RoleEnum
from app.db.models.report import ReportFortnight
from datetime import datetime
from fastapi.responses import StreamingResponse
from app.services.reports_pdf import generate_fortnight_pdf
from io import BytesIO

router = APIRouter(prefix="/fortnight", tags=["fortnight-feedback"])

@router.post("/update")
def update_fortnight_feedback(
    report_id: str,
    progress_percentage: float,
    feedback: str,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if user.role != RoleEnum.mentor:
        raise HTTPException(status_code=403, detail="Only mentors can update reports")

    report = db.query(ReportFortnight).filter(ReportFortnight.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    report.progress_percentage = progress_percentage
    report.feedback = feedback
    report.updated_at = datetime.utcnow()
    db.commit()
    return {"message": "Fortnight feedback updated successfully"}

@router.get("/student/{student_id}")
def get_report(student_id: str, db = Depends(get_db)):
    from datetime import datetime, timedelta
    # example: last 15 days
    to_date = datetime.utcnow()
    from_date = to_date - timedelta(days=15)
    pdf_bytes = generate_fortnight_pdf(db, student_id, from_date, to_date)
    return StreamingResponse(BytesIO(pdf_bytes), media_type="application/pdf", headers={"Content-Disposition": f"attachment; filename=fortnight_{student_id}.pdf"})





