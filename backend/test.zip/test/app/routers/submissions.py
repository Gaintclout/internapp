# app/routers/submissions.py
from fastapi import APIRouter, Depends, HTTPException, UploadFile, Form
from sqlalchemy.orm import Session
from datetime import datetime
import json, uuid, base64, os
from app.core.deps import get_current_user
from app.db.session import get_db
from app.db.models.user import User, RoleEnum
from app.db.models.student import Student
from app.db.models.task import ProjectTask
from app.db.models.submission import Submission
from app.db.models.student_task_status import StudentTaskStatus, TaskState
from app.services.judge0 import create_submission, get_submission
from app.services.unlocks import mark_pass_if_all_tests_pass

router = APIRouter(prefix="/submissions", tags=["submissions"])

def get_model_by_id_flexible(db: Session, model, identifier: str):
    """
    Try to resolve a model by UUID id first, then by raw string id, then by title field (if present).
    Returns instance or None.
    """
    if not identifier:
        return None
    # try UUID
    try:
        uid = uuid.UUID(identifier)
    except Exception:
        uid = None

    if uid is not None:
        # database column might be UUID or CHAR(36)
        try:
            return db.query(model).filter(model.id == uid).first()
        except Exception:
            # fallback to string compare if DB stores id as CHAR(36)
            try:
                return db.query(model).filter(model.id == str(uid)).first()
            except Exception:
                return None

    # not a UUID: try raw id field match (some DBs store as CHAR)
    try:
        q = db.query(model).filter(model.id == identifier).first()
        if q:
            return q
    except Exception:
        pass

    # last fallback: try title/slug lookup
    if hasattr(model, "title"):
        try:
            return db.query(model).filter(getattr(model, "title") == identifier).first()
        except Exception:
            pass

    return None

@router.post("")
async def submit_code(
    task_id: str = Form(...),
    code: str = Form(...),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # small defensive checks
    st = db.query(Student).filter(Student.user_id == user.id).first()
    if not st:
        raise HTTPException(status_code=404, detail="Student profile not found for this user")

    # resolve task flexibly (UUID or string)
    task = get_model_by_id_flexible(db, ProjectTask, task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    # Configurable thresholds (tweak via env if desired) - kept from your code
    MAX_HIDDEN_ATTEMPTS = int(os.getenv("MAX_HIDDEN_ATTEMPTS", "3"))
    OVERRIDE_AFTER_DAYS = int(os.getenv("OVERRIDE_AFTER_DAYS", "7"))
    OVERRIDE_PERCENT = int(os.getenv("OVERRIDE_PERCENT", "80"))
    SYSTEM_OVERRIDE_USER_ID = int(os.getenv("SYSTEM_OVERRIDE_USER_ID", "0"))

    # 1) Submit once to Judge0 (create_submission is async and base64-encodes)
    try:
        create_resp = await create_submission(code, task.judge0_language_id, stdin="")
    except Exception as e:
        # return a clear HTTP error so frontend gets meaningful message
        raise HTTPException(status_code=502, detail=f"Judge0 submission failed: {e}")

    token = create_resp.get("token") if isinstance(create_resp, dict) else None

    # 2) Poll/get final result
    try:
        if token:
            final = await get_submission(token)
        else:
            final = create_resp  # in case create_submission returned final body
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Judge0 fetch failed: {e}")

    # 3) Save submission record
    sub_rec = Submission(
        id=str(uuid.uuid4()),
        student_id=st.id,
        task_id=task.id,
        code_url="",
        judge0_token=token or "",
        judge0_status=json.dumps(final or {}),
        passed=False
    )
    db.add(sub_rec)
    db.flush()  # get id if DB populated, though we already set id

    # 4) Ensure StudentTaskStatus exists
    sts = db.query(StudentTaskStatus).filter(
        StudentTaskStatus.student_id == st.id,
        StudentTaskStatus.task_id == task.id
    ).first()
    if not sts:
        sts = StudentTaskStatus(student_id=st.id, task_id=task.id, status=TaskState.in_progress, attempts=0)
        db.add(sts)
        db.flush()

    # link submission + increment attempt counter
    sts.attempts = (getattr(sts, "attempts", 0) or 0) + 1
    sts.last_submission_id = sub_rec.id

    # 5) Extract and decode stdout (Judge0 was called with base64_encoded=true)
    raw_stdout = ""
    if isinstance(final, dict):
        raw_stdout = final.get("stdout") or ""
    else:
        raw_stdout = ""

    decoded_stdout = raw_stdout
    try:
        # some Judge0 setups return base64 string when base64_encoded=true
        decoded_stdout = base64.b64decode(raw_stdout).decode()
    except Exception:
        decoded_stdout = raw_stdout

    # Try to parse JSON (prefer entire stdout or last non-empty line)
    parsed = None
    try:
        parsed = json.loads(decoded_stdout)
    except Exception:
        lines = [ln.strip() for ln in decoded_stdout.splitlines() if ln.strip()]
        if lines:
            try:
                parsed = json.loads(lines[-1])
            except Exception:
                parsed = None

    now = datetime.utcnow()

    # helper: unlock next for this student (create StudentTaskStatus if missing)
    def unlock_next_for_student():
        nxt = db.query(ProjectTask).filter(
            ProjectTask.student_project_id == task.student_project_id,
            ProjectTask.order_index == task.order_index + 1
        ).first()
        if not nxt:
            return
        nxt_sts = db.query(StudentTaskStatus).filter_by(student_id=st.id, task_id=nxt.id).first()
        if not nxt_sts:
            nxt_sts = StudentTaskStatus(student_id=st.id, task_id=nxt.id, status=TaskState.in_progress, attempts=0)
            db.add(nxt_sts)
            db.flush()
        nxt_sts.unlocked_at = now
        db.add(nxt_sts)

    # 6) If no structured JSON, use Judge0 status.id fallback
    if not isinstance(parsed, dict):
        status_id = (final.get("status") or {}).get("id", 0) if isinstance(final, dict) else 0
        if status_id == 3:
            # Accepted -> treat as pass
            sts.status = TaskState.passed
            sts.progress_percent = 100
            if hasattr(sts, "passed_at"):
                sts.passed_at = now
            sub_rec.passed = True
            db.add(sts)
            unlock_next_for_student()
            db.commit()
            return {"submission_id": sub_rec.id, "passed": True, "action": "complete_fallback", "status_id": status_id, "judge0": final}
        else:
            sts.status = TaskState.failed
            db.add(sts)
            db.commit()
            return {"submission_id": sub_rec.id, "passed": False, "action": "fail_fallback", "status_id": status_id, "judge0": final}

    # 7) Structured JSON present: expected shape:
    #    {"public": {"passed":X,"total":Y}, "hidden": {"passed":A,"total":B}}
    public = parsed.get("public", {})
    hidden = parsed.get("hidden", {})
    p_total = int(public.get("total", 0))
    p_passed = int(public.get("passed", 0))
    h_total = int(hidden.get("total", 0))
    h_passed = int(hidden.get("passed", 0))

    # Case A: public tests failed => immediate fail
    if p_total > 0 and p_passed < p_total:
        sts.status = TaskState.failed
        db.add(sts)
        db.commit()
        sub_rec.passed = False
        return {"submission_id": sub_rec.id, "passed": False, "action": "fail_public", "public_total": p_total, "public_passed": p_passed, "judge0": final}

    # Case B: public ok and hidden all passed => complete normally
    if h_total == 0 or h_passed == h_total:
        sts.status = TaskState.passed
        sts.hidden_attempts = 0
        sts.progress_percent = 100
        if hasattr(sts, "passed_at"):
            sts.passed_at = now
        sub_rec.passed = True
        db.add(sts)
        unlock_next_for_student()
        db.commit()
        return {"submission_id": sub_rec.id, "passed": True, "action": "complete", "public_passed": p_passed, "hidden_passed": h_passed, "judge0": final}

    # Case C: public ok but hidden failing -> increment hidden_attempts and possibly auto-override
    sts.hidden_attempts = (getattr(sts, "hidden_attempts", 0) or 0) + 1
    if not getattr(sts, "first_hidden_attempt_at", None):
        sts.first_hidden_attempt_at = now
    db.add(sts); db.commit()

    attempts = getattr(sts, "hidden_attempts", 0) or 0
    days_since = (now - sts.first_hidden_attempt_at).days if getattr(sts, "first_hidden_attempt_at", None) else 0

    if attempts >= MAX_HIDDEN_ATTEMPTS or days_since >= OVERRIDE_AFTER_DAYS:
        # auto-override: mark passed with OVERRIDE_PERCENT and unlock next
        sts.mentor_override = True
        sts.mentor_override_by = SYSTEM_OVERRIDE_USER_ID
        sts.mentor_override_at = now
        sts.mentor_override_note = f"Auto-override after {attempts} hidden attempts / {days_since} days"
        sts.progress_percent = OVERRIDE_PERCENT
        sts.status = TaskState.passed
        if hasattr(sts, "passed_at"):
            sts.passed_at = now
        sub_rec.passed = True
        db.add(sts)
        unlock_next_for_student()
        db.commit()
        return {"submission_id": sub_rec.id, "passed": True, "action": "auto_override", "attempts": attempts, "days_since": days_since, "judge0": final}

    # Otherwise, hidden failing but not yet overridden -> student may retry
    sts.status = TaskState.failed
    db.add(sts)
    db.commit()
    return {"submission_id": sub_rec.id, "passed": False, "action": "hidden_fail", "attempts": attempts, "days_since": days_since, "hidden_passed": h_passed, "judge0": final}
