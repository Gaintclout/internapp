from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db.models.user import RoleEnum
from app.db.models.user import User
from app.db.models.payment import Payment
from app.db.models.project import Project
from app.core.deps import require_admin

router = APIRouter(prefix="/admin", tags=["admin"])

@router.get("/dashboard/metrics")
def metrics(user: User = Depends(require_admin), db: Session = Depends(get_db)):
    total_users = db.query(User).count()
    total_projects = db.query(Project).count()
    total_payments = db.query(Payment).count()
    total_collected = sum(p.amount_inr for p in db.query(Payment).all())
    return {"total_users": total_users, "projects": total_projects, "payments": total_payments, "amount_collected": total_collected}
