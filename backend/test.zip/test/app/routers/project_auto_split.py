# app/routers/project_auto_split.py
import zipfile, os, uuid
from fastapi import APIRouter, UploadFile, Depends, HTTPException
from app.services.judge0 import create_submission
from app.db.session import get_db
from sqlalchemy.orm import Session
from app.db.models.project import Project
from app.db.models.task import ProjectTask
import uuid

router = APIRouter(prefix="/project_auto_split", tags=["predefined-projects"])

from fastapi import Depends

@router.post("/upload")
async def upload_project_zip(
    file: UploadFile,
    project_title: str,
    language_id: int,
    db: Session = Depends(get_db),
):

    temp_dir = "temp_uploads"
    os.makedirs(temp_dir, exist_ok=True)
    zip_path = os.path.join(temp_dir, file.filename)

    with open(zip_path, "wb") as f:
        f.write(await file.read())

    # Extract all files
    extract_dir = os.path.join(temp_dir, file.filename.split(".")[0])
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(extract_dir)

    # Create a new Project
    proj = Project(id=str(uuid.uuid4()), title=project_title, technology="AutoImported")
    db.add(proj)
    db.flush()

    seq = 1
    for root, dirs, files in os.walk(extract_dir):
        for filename in files:
            if filename.endswith((".py", ".js", ".cpp")):
                file_path = os.path.join(root, filename)
                with open(file_path, "r", encoding="utf-8") as code_file:
                    code = code_file.read()
                # create judge0 task
                sub = await create_submission(code, language_id)
                db.add(ProjectTask(
                    id=str(uuid.uuid4()),
                    project_id=proj.id,
                    seq=seq,
                    title=f"Task-{seq}: {filename}",
                    description="Auto-split task from predefined project.",
                    judge0_language_id=language_id,
                    judge0_template_code=code,
                    hidden_tests=[],
                    is_learning_task=True if seq == 1 else False
                ))
                seq += 1
    db.commit()
    return {"message": "Project imported successfully", "tasks_created": seq - 1}
