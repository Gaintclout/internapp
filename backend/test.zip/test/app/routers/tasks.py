from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.deps import get_current_user
from app.db.session import get_db
from app.db.models.user import User, RoleEnum
from app.db.models.student import Student, InternshipType
from app.db.models.task import ProjectTask
from app.db.models.student_task_status import StudentTaskStatus, TaskState
from app.services.unlocks import visible_tasks_for_student

router = APIRouter(prefix="/tasks", tags=["tasks"])

@router.get("")
def list_visible_tasks(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    st = db.query(Student).filter(Student.user_id == user.id).first()
    if not st or not st.project_id:
        raise HTTPException(status_code=400, detail="No project selected")
    return visible_tasks_for_student(db, st)
