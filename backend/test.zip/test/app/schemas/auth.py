from pydantic import BaseModel, EmailStr

class RegisterStudent(BaseModel):
    name: str
    college_email: str
    phone: str | None = None
    password: str
    college_name: str | None = None
    pursuing_year: str | None = None

class Login(BaseModel):
    email: str
    password: str

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
