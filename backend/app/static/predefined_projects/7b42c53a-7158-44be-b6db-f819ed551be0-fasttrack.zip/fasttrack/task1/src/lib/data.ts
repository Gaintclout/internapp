export type Email = {
  id: string;
  from: string;
  fromEmail: string;
  subject: string;
  snippet: string;
  body: string;
  date: string;
  isRead: boolean;
  isSpam: boolean;
  avatar: string;
  ipAddress: string;
};

export const emails: Email[] = [
  {
    id: "1",
    from: "Alice",
    fromEmail: "alice@example.com",
    subject: "Project Update",
    snippet: "Here's the latest update on the project timeline.",
    body: "Hi Team,\n\nHere's the latest update on the project timeline. We are on track to meet the deadline. Please review the attached document.\n\nBest,\nAlice",
    date: "3:45 PM",
    isRead: false,
    isSpam: false,
    avatar: "https://picsum.photos/40/40?grayscale&random=1",
    ipAddress: "198.51.100.1",
  },
  {
    id: "2",
    from: "Bob",
    fromEmail: "bob@example.com",
    subject: "Lunch tomorrow?",
    snippet: "Are you free for lunch tomorrow to discuss the new design?",
    body: "Hey,\n\nAre you free for lunch tomorrow to discuss the new design? Let me know what time works for you.\n\nCheers,\nBob",
    date: "1:20 PM",
    isRead: true,
    isSpam: false,
    avatar: "https://picsum.photos/40/40?grayscale&random=2",
    ipAddress: "198.51.100.2",
  },
  {
    id: "3",
    from: "Nigerian Prince",
    fromEmail: "scam@example.com",
    subject: "Urgent Business Proposal! YOU WON!",
    snippet: "Click here to claim your prize of $1,000,000!",
    body: "Dear Friend,\n\nI am a Nigerian prince and I need your help to transfer $10,000,000 out of my country. If you help me, I will give you 10% of the money. Please send me your bank details so I can transfer the money.\n\nTHIS IS NOT A SCAM! YOU ARE A WINNER! free money lottery viagra\n\nSincerely,\nPrince Ade",
    date: "11:00 AM",
    isRead: false,
    isSpam: true,
    avatar: "https://picsum.photos/40/40?grayscale&random=3",
    ipAddress: "203.0.113.55",
  },
  {
    id: "4",
    from: "Carol",
    fromEmail: "carol@example.com",
    subject: "Your order has shipped",
    snippet: "Your order #12345 has been shipped and is on its way.",
    body: "Hi Carol,\n\nGreat news! Your order #12345 has been shipped and is on its way. You can track your package using the link below.\n\nThank you for your purchase!",
    date: "Yesterday",
    isRead: true,
    isSpam: false,
    avatar: "https://picsum.photos/40/40?grayscale&random=4",
    ipAddress: "198.51.100.3",
  },
  {
    id: "5",
    from: "Best Deals Inc.",
    fromEmail: "deals@spam.net",
    subject: "Exclusive Offer Just For You",
    snippet: "Don't miss out on these amazing deals! Limited time only.",
    body: "Hello,\n\nWe have an exclusive offer just for you! Get 90% off on all our products. This is a limited-time offer, so act fast! Click the link to shop now. viagra special offer.\n\nThanks,\nBest Deals Inc.",
    date: "Yesterday",
    isRead: false,
    isSpam: true,
    avatar: "https://picsum.photos/40/40?grayscale&random=5",
    ipAddress: "98.51.100.3",
  },
  {
    id: "6",
    from: "Dave",
    fromEmail: "dave@example.com",
    subject: "Re: Meeting notes",
    snippet: "Thanks for sending those over. I've added my comments.",
    body: "Hi,\n\nThanks for sending those over. I've added my comments to the document. Let me know if you have any questions.\n\nBest,\nDave",
    date: "2 days ago",
    isRead: true,
    isSpam: false,
    avatar: "https://picsum.photos/40/40?grayscale&random=6",
    ipAddress: "198.51.100.4",
  },
    {
    id: "7",
    from: "Pharma Store",
    fromEmail: "pills@spam-central.org",
    subject: "Get Your Meds Cheaper",
    snippet: "Amazing discounts on all your favorite medications. V1agra, C1alis, and more.",
    body: "Tired of paying high prices for your medication? We offer top quality generic drugs at a fraction of the price. V.I.A.G.R.A, CIALIS, and more. Discreet shipping worldwide. Order now and get a free bonus!",
    date: "3 days ago",
    isRead: false,
    isSpam: true,
    avatar: "https://picsum.photos/40/40?grayscale&random=7",
    ipAddress: "104.28.23.78",
  },
  {
    id: "8",
    from: "Eve",
    fromEmail: "eve@example.com",
    subject: "Holiday pictures",
    snippet: "I've uploaded the pictures from our trip!",
    body: "Hey everyone,\n\nI've finally uploaded the pictures from our amazing trip! You can find them in the shared album here. Let me know which ones are your favorites!\n\nBest,\nEve",
    date: "3 days ago",
    isRead: true,
    isSpam: false,
    avatar: "https://picsum.photos/40/40?grayscale&random=8",
    ipAddress: "198.51.100.5",
  },
];
