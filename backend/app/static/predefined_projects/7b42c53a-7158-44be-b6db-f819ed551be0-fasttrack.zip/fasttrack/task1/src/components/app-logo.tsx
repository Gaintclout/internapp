import { Mailbox } from 'lucide-react';

export function AppLogo() {
  return (
    <div className="flex items-center gap-2 font-semibold text-foreground">
      <Mailbox className="h-6 w-6 text-primary" />
      <span className="font-headline text-lg tracking-tight">Spam ShieldX</span>
    </div>
  );
}
