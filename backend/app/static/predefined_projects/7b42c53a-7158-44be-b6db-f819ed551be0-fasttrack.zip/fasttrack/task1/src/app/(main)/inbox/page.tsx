import { emails } from '@/lib/data';
import { EmailList } from '@/components/email/email-list';

export default async function InboxPage() {
  const inboxEmails = emails.filter((email) => !email.isSpam);
  
  return (
    <div className="flex h-full flex-col">
      <header className="border-b bg-card p-4">
        <h1 className="text-2xl font-bold tracking-tight">Inbox</h1>
        <p className="text-sm text-muted-foreground">
          You have {inboxEmails.length} messages in your inbox.
        </p>
      </header>
      <div className="flex-1 overflow-auto">
        <EmailList emails={inboxEmails} type="inbox" />
      </div>
    </div>
  );
}
