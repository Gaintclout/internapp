import { config } from 'dotenv';
config();

import '@/ai/flows/report-misclassified-email.ts';
import '@/ai/flows/suggest-keywords.ts';