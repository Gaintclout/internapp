'use server';

/**
 * @fileOverview An AI agent that suggests relevant keywords for spam filtering based on past email history and common spam patterns.
 *
 * - suggestKeywords - A function that suggests keywords for spam filtering.
 * - SuggestKeywordsInput - The input type for the suggestKeywords function.
 * - SuggestKeywordsOutput - The return type for the suggestKeywords function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestKeywordsInputSchema = z.object({
  emailHistory:
    z.string()
      .describe('The user email history to extract keywords from.'),
});
export type SuggestKeywordsInput = z.infer<typeof SuggestKeywordsInputSchema>;

const SuggestKeywordsOutputSchema = z.object({
  keywords:
    z.array(z.string())
      .describe(
        'An array of suggested keywords for spam filtering based on the email history.'
      ),
});
export type SuggestKeywordsOutput = z.infer<typeof SuggestKeywordsOutputSchema>;

export async function suggestKeywords(input: SuggestKeywordsInput): Promise<SuggestKeywordsOutput> {
  return suggestKeywordsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestKeywordsPrompt',
  input: {schema: SuggestKeywordsInputSchema},
  output: {schema: SuggestKeywordsOutputSchema},
  prompt: `You are an AI assistant designed to suggest keywords for spam filtering.

  Analyze the following email history and identify potential keywords that are indicative of spam.
  Consider common spam patterns, misspellings, and suspicious phrases.

  Email History: {{{emailHistory}}}

  Suggest at least 5 keywords.
  Format the output as JSON array of strings.`,
});

const suggestKeywordsFlow = ai.defineFlow(
  {
    name: 'suggestKeywordsFlow',
    inputSchema: SuggestKeywordsInputSchema,
    outputSchema: SuggestKeywordsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
