// This is a server-side file!
'use server';

/**
 * @fileOverview Allows users to report misclassified emails (spam in inbox, or vice-versa) to improve future filtering accuracy.
 *
 * @remarks
 * This flow takes the email content and classification as input, and then uses this information to train the AI model.
 *
 * @exports `reportMisclassifiedEmail` - The exported function to report misclassified emails.
 * @exports `ReportMisclassifiedEmailInput` - The input type for the `reportMisclassifiedEmail` function.
 * @exports `ReportMisclassifiedEmailOutput` - The output type for the `reportMisclassifiedEmail` function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const ReportMisclassifiedEmailInputSchema = z.object({
  emailContent: z.string().describe('The full content of the email.'),
  isSpam: z.boolean().describe('True if the email was incorrectly classified as not spam, false otherwise.'),
});
export type ReportMisclassifiedEmailInput = z.infer<typeof ReportMisclassifiedEmailInputSchema>;

const ReportMisclassifiedEmailOutputSchema = z.object({
  success: z.boolean().describe('Indicates whether the reporting was successful.'),
  message: z.string().describe('A message indicating the outcome of the reporting.'),
});
export type ReportMisclassifiedEmailOutput = z.infer<typeof ReportMisclassifiedEmailOutputSchema>;

/**
 * Reports a misclassified email to improve future filtering accuracy.
 * @param input - The input containing the email content and classification.
 * @returns A promise resolving to the output of the reporting process.
 */
export async function reportMisclassifiedEmail(input: ReportMisclassifiedEmailInput): Promise<ReportMisclassifiedEmailOutput> {
  return reportMisclassifiedEmailFlow(input);
}

const reportMisclassifiedEmailFlow = ai.defineFlow(
  {
    name: 'reportMisclassifiedEmailFlow',
    inputSchema: ReportMisclassifiedEmailInputSchema,
    outputSchema: ReportMisclassifiedEmailOutputSchema,
  },
  async input => {
    // Here, you would typically integrate with a system to store
    // the misclassified email data and use it to retrain your AI model.
    // For this example, we'll simulate a successful reporting.

    console.log(
      `User reported email as ${input.isSpam ? 'incorrectly classified as not spam' : 'incorrectly classified as spam'}.`
    );

    // Simulate a successful reporting and model retraining (replace with actual logic).
    return {
      success: true,
      message: `Email reported successfully. The AI model will be updated to improve accuracy.`,      
    };
  }
);
