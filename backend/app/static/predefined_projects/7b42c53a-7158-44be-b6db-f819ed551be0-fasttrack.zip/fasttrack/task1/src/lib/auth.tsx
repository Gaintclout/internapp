'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { Loader2 } from 'lucide-react';

type User = {
  email: string;
};

type AuthContextType = {
  user: User | null;
  login: (email: string, pass: string) => Promise<void>;
  signup: (name: string, email: string, pass: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const DUMMY_USER_KEY = 'dummy_user_credentials';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    // Check if user is "logged in" from a previous session
    const storedUser = sessionStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    if (loading) return;

    const authPages = ['/login', '/signup'];
    const isAuthPage = authPages.includes(pathname);
    
    if (!user && !isAuthPage) {
      router.push('/login');
    } else if (user && isAuthPage) {
      router.push('/inbox');
    }
  }, [user, loading, pathname, router]);


  const login = async (email: string, pass: string): Promise<void> => {
     return new Promise((resolve, reject) => {
      setTimeout(() => {
        const storedCredentials = sessionStorage.getItem(DUMMY_USER_KEY);
        let credentials = { email: 'user@example.com', password: 'password' };

        if (storedCredentials) {
            credentials = JSON.parse(storedCredentials);
        }

        if (email === credentials.email && pass === credentials.password) {
          const userData = { email };
          setUser(userData);
          sessionStorage.setItem('user', JSON.stringify(userData));
          router.push('/inbox');
          resolve();
        } else {
          reject(new Error('Invalid email or password.'));
        }
      }, 1000);
    });
  };

  const signup = async (name: string, email: string, pass: string): Promise<void> => {
    return new Promise((resolve) => {
     setTimeout(() => {
       // Simulate creating a new user and logging them in
       const userData = { email };
       sessionStorage.setItem(DUMMY_USER_KEY, JSON.stringify({ email, password: pass }));
       setUser(userData);
       sessionStorage.setItem('user', JSON.stringify(userData));
       router.push('/inbox');
       resolve();
     }, 1000);
   });
 };

  const logout = () => {
    setUser(null);
    sessionStorage.removeItem('user');
    // We could also remove the DUMMY_USER_KEY here if we want the signup to be forgotten on logout.
    // sessionStorage.removeItem(DUMMY_USER_KEY);
    router.push('/login');
  };
  
  const authPages = ['/login', '/signup'];
  const isAuthPage = authPages.includes(pathname);

  if (loading || (!user && !isAuthPage)) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
