# task2-frontend-logic
Frontend Logic & State Mgmt