# task8-deployment
Deployment configs