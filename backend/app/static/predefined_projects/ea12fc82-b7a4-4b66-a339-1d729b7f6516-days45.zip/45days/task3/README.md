Task3: Integration & Config
