Task1: UI/Auth/Layout
