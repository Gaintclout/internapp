'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Mail, FileText, CheckCircle2, XCircle, MoreHorizontal, LogOut, Loader2, RefreshCw } from 'lucide-react';

import type { Applicant } from '@/lib/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { getSkillsMatch } from '@/app/actions';
import { useToast } from '@/hooks/use-toast';

export default function AdminDashboard() {
  const [applicants, setApplicants] = useState<Applicant[]>([]);
  const [isReevaluating, setIsReevaluating] = useState(false);
  const [isClient, setIsClient] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  useEffect(() => {
    setIsClient(true);
    try {
      const storedApplicants = localStorage.getItem('applicants');
      if (storedApplicants) {
        setApplicants(JSON.parse(storedApplicants));
      }
    } catch (error) {
      // local storage not available
    }
  }, []);

  const handleLogout = () => {
    try {
      sessionStorage.removeItem('isAdminAuthenticated');
      router.push('/admin/login');
    } catch (error) {
        // session storage not available
    }
  };

  const handleReevaluate = async () => {
    setIsReevaluating(true);
    try {
      let storedApplicants;
      try {
        storedApplicants = localStorage.getItem('applicants');
      } catch (error) {
        toast({ title: "Could not access applicant data."});
        return;
      }

      if (!storedApplicants) {
        toast({ title: "No applicants to re-evaluate."});
        return;
      }

      const currentApplicants: Applicant[] = JSON.parse(storedApplicants);
      
      const updatedApplicants = await Promise.all(
        currentApplicants.map(async (applicant) => {
          if (!applicant.resumeUrl) {
            return applicant; // Skip if no resume
          }

          const aiResult = await getSkillsMatch(applicant.resumeUrl);

          if (aiResult.success && aiResult.data) {
             const { skillsMatchPercentage } = aiResult.data;
              let status: Applicant['status'];
              if (skillsMatchPercentage < 60) {
                status = 'Rejected';
              } else {
                status = 'Shortlisted';
              }
            return {
              ...applicant,
              skillsMatchPercentage: aiResult.data.skillsMatchPercentage,
              missingSkills: aiResult.data.missingSkills,
              status: status,
            };
          }
          return applicant; // Return original applicant if AI fails
        })
      );
      
      setApplicants(updatedApplicants);
       try {
        localStorage.setItem('applicants', JSON.stringify(updatedApplicants));
      } catch (error) {
        // local storage not available
      }


      toast({
        title: "Re-evaluation Complete",
        description: "All applicants have been re-evaluated with the latest skill-matching logic.",
      });
    } catch (error) {
      console.error("Re-evaluation failed:", error);
      toast({
        variant: 'destructive',
        title: "An error occurred during re-evaluation.",
        description: error instanceof Error ? error.message : "Please try again.",
      });
    } finally {
      setIsReevaluating(false);
    }
  };


  const updateApplicantStatus = (id: string, status: Applicant['status']) => {
    const updatedApplicants = applicants.map((applicant) =>
      applicant.id === id ? { ...applicant, status } : applicant
    );
    setApplicants(updatedApplicants);
    try {
      localStorage.setItem('applicants', JSON.stringify(updatedApplicants));
    } catch (error) {
      // local storage not available
    }
  };

  const getStatusBadgeVariant = (status: Applicant['status']) => {
    switch (status) {
      case 'Shortlisted':
        return 'default';
      case 'Rejected':
        return 'destructive';
      default:
        return 'secondary';
    }
  };
  
  const getMailtoLink = (applicant: Applicant) => {
    const { name, email, status } = applicant;
    let subject = '';
    let body = '';

    if (status === 'Rejected') {
      subject = 'Update on Your Application with gaint';
      body = `Dear ${name},\n\nThank you for your interest and for taking the time to apply. After careful consideration, we have decided not to move forward with your application at this time.\n\nWe wish you the best of luck in your job search.\n\nSincerely,\nThe gaint Team`;
    } else if (status === 'Shortlisted') {
      subject = 'Congratulations! You Have Been Shortlisted';
      body = `Dear ${name},\n\nCongratulations! We are pleased to inform you that your application has been shortlisted for the next stage of our recruitment process.\n\nWe will be in touch shortly with the next steps.\n\nSincerely,\nThe gaint Team`;
    } else {
        return `mailto:${email}`;
    }

    return `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };
  
  if (!isClient) {
    // Render nothing on the server to avoid hydration mismatch
    return null;
  }

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex justify-end gap-2 mb-4">
            <Button variant="outline" onClick={handleReevaluate} disabled={isReevaluating}>
              {isReevaluating ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="mr-2 h-4 w-4" />
              )}
              Re-evaluate All
            </Button>
            <Button variant="outline" onClick={handleLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                Logout
            </Button>
        </div>
        <TooltipProvider>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead className="text-center">Skills Match</TableHead>
                  <TableHead className="text-center">Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {applicants.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="h-24 text-center">
                      No applicants yet.
                    </TableCell>
                  </TableRow>
                ) : (
                  applicants.map((applicant) => (
                    <TableRow key={applicant.id}>
                      <TableCell className="font-medium">{applicant.name}</TableCell>
                      <TableCell className="text-center">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div className="flex flex-col items-center space-y-1">
                               <span>{applicant.skillsMatchPercentage}%</span>
                               <Progress value={applicant.skillsMatchPercentage} className="w-24 h-2" />
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Missing Skills: {applicant.missingSkills || 'None'}</p>
                          </TooltipContent>
                        </Tooltip>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant={getStatusBadgeVariant(applicant.status)}>{applicant.status}</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end space-x-2">
                           <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="icon" asChild>
                                   <Link href={applicant.resumeUrl} target="_blank" rel="noopener noreferrer">
                                     <FileText className="h-4 w-4" />
                                   </Link>
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent><p>View Resume</p></TooltipContent>
                           </Tooltip>
                           <Tooltip>
                             <TooltipTrigger asChild>
                               <Button variant="ghost" size="icon" asChild>
                                 <a href={getMailtoLink(applicant)}>
                                   <Mail className="h-4 w-4" />
                                 </a>
                               </Button>
                             </TooltipTrigger>
                             <TooltipContent><p>Mail Applicant</p></TooltipContent>
                           </Tooltip>
                           <DropdownMenu>
                             <DropdownMenuTrigger asChild>
                               <Button variant="ghost" size="icon">
                                 <MoreHorizontal className="h-4 w-4" />
                               </Button>
                             </DropdownMenuTrigger>
                             <DropdownMenuContent align="end">
                               <DropdownMenuItem onClick={() => updateApplicantStatus(applicant.id, 'Shortlisted')}>
                                 <CheckCircle2 className="mr-2 h-4 w-4" />
                                 Shortlist
                               </DropdownMenuItem>
                               <DropdownMenuItem onClick={() => updateApplicantStatus(applicant.id, 'Rejected')}>
                                 <XCircle className="mr-2 h-4 w-4" />
                                 Reject
                               </DropdownMenuItem>
                             </DropdownMenuContent>
                           </DropdownMenu>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </TooltipProvider>
      </CardContent>
    </Card>
  );
}
