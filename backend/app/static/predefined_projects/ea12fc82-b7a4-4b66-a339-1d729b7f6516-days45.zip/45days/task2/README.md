Task2: Candidate/Admin modules
