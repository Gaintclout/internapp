from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import subprocess
import datetime
import webbrowser
import platform
import os
import pyttsx3
import pathlib

app = FastAPI()

# CORS Setup
origins = ["http://localhost:3000", "http://localhost:3001"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Text-to-speech setup
engine = pyttsx3.init()
engine.setProperty("rate", 170)

class Command(BaseModel):
    command: str

# Predefined Windows app paths with fallbacks
WINDOWS_APPS = {
    # System apps
    "notepad": r"C:\Windows\System32\notepad.exe",
    "paint": r"C:\Users\ROHINI\AppData\Local\Microsoft\WindowsApps\mspaint.exe",
    "calculator": r"C:\Windows\System32\calc.exe",

    # Browsers
    "chrome": r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    "edge": r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    "firefox": r"C:\Program Files\Mozilla Firefox\firefox.exe",

    # VS Code
    "vscode": r"C:\Users\ROHINI\AppData\Local\Programs\Microsoft VS Code\Code.exe",

    # Spotify fallback paths will be handled dynamically below
    "spotify": r"C:\Users\ROHINI\AppData\Roaming\Spotify\Spotify.exe",

    # Microsoft Office Suite (Office 365 default path)
    "word": r"C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE",
    "excel": r"C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE",
    "powerpoint": r"C:\Program Files\Microsoft Office\root\Office16\POWERPNT.EXE",
    "outlook": r"C:\Program Files (x86)\Microsoft Office\root\Office16\OUTLOOK.EXE"

}

# App name aliases for better voice recognition
APP_ALIASES = {
    "vs code": "vscode",
    "visual studio code": "vscode",
    "code": "vscode",
    "ms paint": "paint",
    "paint app": "paint",
    "calculator app": "calculator",
    "calc": "calculator",
    "chrome browser": "chrome",
    "microsoft edge": "edge",
    "edge browser": "edge",
    "firefox browser": "firefox",
    "spotify app": "spotify",
    "spotify music": "spotify",
    "word app": "word",
    "ms word": "word",
    "excel app": "excel",
    "ms excel": "excel",
    "powerpoint app": "powerpoint",
    "ms powerpoint": "powerpoint",
    "ppt": "powerpoint",
    "outlook app": "outlook",
    "ms outlook": "outlook"
}

# Function to normalize spoken commands
def normalize_app_name(app_name: str):
    app_name = app_name.lower().strip()
    return APP_ALIASES.get(app_name, app_name)

# Function to verify app path exists
def find_app_path(app_name):
    path = WINDOWS_APPS.get(app_name)
    if path and pathlib.Path(path).exists():
        return path

    # Fallback for Spotify (Microsoft Store version)
    if app_name == "spotify":
        store_path = pathlib.Path(r"C:\Program Files\WindowsApps")
        for path in store_path.glob("SpotifyAB.SpotifyMusic_*"):
            potential = path / "Spotify.exe"
            if potential.exists():
                return str(potential)
    return None

# Open app based on OS
def open_application(app_name: str):
    os_name = platform.system()
    app_name = normalize_app_name(app_name)

    try:
        if os_name == "Windows":
            app_path = find_app_path(app_name)
            if app_path:
                subprocess.Popen(app_path, shell=True)
                return f"Opening {app_name}"
            else:
                subprocess.Popen(f'start "" "{app_name}"', shell=True)
                return f"Opening {app_name}"

        elif os_name == "Darwin":  # macOS
            subprocess.Popen(["open", "-a", app_name])
            return f"Opening {app_name}"

        elif os_name == "Linux":
            subprocess.Popen([app_name])
            return f"Opening {app_name}"

        else:
            return "Unsupported operating system!"

    except Exception as e:
        return f"Couldn't open {app_name}: {e}"

@app.post("/process")
async def process_command(data: Command):
    command = data.command.lower().strip()
    response = ""

    if command.startswith("open "):
        app_name = command.replace("open ", "").strip()
        response = open_application(app_name)

    elif command in WINDOWS_APPS:
        response = open_application(command)

    elif "search" in command:
        query = command.replace("search", "").strip()
        url = f"https://www.google.com/search?q={query}"
        webbrowser.open(url)
        response = f"Searching for {query}"

    elif "time" in command:
        response = "The current time is " + datetime.datetime.now().strftime("%I:%M %p")

    elif "date" in command:
        response = "Today's date is " + datetime.datetime.now().strftime("%A, %B %d, %Y")

    elif "exit" in command or "quit" in command:
        response = "Goodbye!"

    else:
        response = "I heard: " + command

    # Speak the response
    engine.say(response)
    engine.runAndWait()

    return {"response": response}
