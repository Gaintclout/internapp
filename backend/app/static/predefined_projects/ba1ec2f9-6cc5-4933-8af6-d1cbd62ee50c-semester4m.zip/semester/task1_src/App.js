import React, { useState, useRef } from "react";
import axios from "axios";
import "./App.css";
import siriMic from "./siri-mic.png"; // <-- Use your provided Siri mic icon

export default function App() {
  const [command, setCommand] = useState("");
  const [response, setResponse] = useState("");
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef(null);

  const handleSubmit = async () => {
    if (!command) return;
    const res = await axios.post("http://127.0.0.1:8000/process", { command });
    setResponse(res.data.response);
  };
const handleVoice = async () => {
  if (!("webkitSpeechRecognition" in window)) {
    alert("Voice recognition not supported!");
    return;
  }

  const recognition = new window.webkitSpeechRecognition();
  recognition.lang = "en-US";
  recognition.start();
  setIsListening(true);

  recognition.onresult = async (event) => {
    let spokenCommand = event.results[0][0].transcript;

    // ✅ Clean spoken command
    spokenCommand = spokenCommand
      .toLowerCase() // lowercase
      .replace(/\.+$/, "") // remove trailing dots
      .replace(/[^\w\s]/gi, "") // remove special characters
      .trim(); // remove spaces

    setCommand(spokenCommand);

    try {
      const res = await axios.post("http://127.0.0.1:8000/process", {
        command: spokenCommand,
      });
      setResponse(res.data.response);
    } catch (error) {
      console.error("Error sending command:", error);
      setResponse("Failed to process command");
    }

    setIsListening(false);
  };

  recognition.onerror = (event) => {
    console.error("Speech recognition error:", event.error);
    setIsListening(false);
  };

  recognition.onend = () => {
    setIsListening(false);
  };

  recognitionRef.current = recognition;
};


  return (
    <div className="app-container">
      <h1>Siri-like Assistant</h1>

      <div
        className={`siri-button ${isListening ? "listening" : ""}`}
        onClick={handleVoice}
      >
        <img src={siriMic} alt="Siri Mic" />
      </div>

      <input
        type="text"
        placeholder="Type or speak your command..."
        value={command}
        onChange={(e) => setCommand(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
      />

      <div className="response">{response && <p>Siri: {response}</p>}</div>
    </div>
  );
}
