import React, { useState } from "react";

export default function VoiceAssistant() {
  const [command, setCommand] = useState("");
  const [response, setResponse] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!command.trim()) return;

    const res = await fetch("http://127.0.0.1:8000/process", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ command }),
    });

    const data = await res.json();
    setResponse(data.response);
  };

  return (
    <div className="voice-assistant">
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={command}
          onChange={(e) => setCommand(e.target.value)}
          placeholder="Say or type a command…"
        />
        <button type="submit">Ask Siri</button>
      </form>
      {response && <p className="response">🧠 Siri: {response}</p>}
    </div>
  );
}
