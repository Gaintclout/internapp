Task2: Additional logic (placeholder)
