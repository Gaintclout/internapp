Task1: Core backend
