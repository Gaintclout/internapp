from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, HttpUrl
from typing import Optional, List, Dict, Any, Tuple
import requests
from bs4 import BeautifulSoup
import re
from urllib.parse import urlparse



app = FastAPI(title="Fake News Detector API", version="1.0.0")

# CORS: allow local dev frontends
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

CLICKBAIT_PHRASES = [
    "you won't believe", "shocking", "what happened next", "breaks the internet",
    "surprising truth", "exposed", "goes viral", "unbelievable", "secret they don't want you to know",
    "one weird trick", "instantly", "guaranteed"
]

KNOWN_SOURCES = {
    # Very small illustrative list. Higher is more trustworthy.
    "nytimes.com": 0.9,
    "theguardian.com": 0.85,
    "bbc.com": 0.9,
    "reuters.com": 0.95,
    "apnews.com": 0.92,
    "washingtonpost.com": 0.88,
    "aljazeera.com": 0.82,
}


class AnalyzeRequest(BaseModel):
    url: Optional[HttpUrl] = None
    text: Optional[str] = None


class AnalyzeResponse(BaseModel):
    title: Optional[str]
    source_domain: Optional[str]
    word_count: int
    credibility_score: float
    flags: List[str]
    indicators: Dict[str, Any]
    excerpt: Optional[str]


def extract_text_from_html(html: str) -> Dict[str, Optional[str]]:
    soup = BeautifulSoup(html, "html.parser")

    # Try typical title locations
    title = None
    if soup.title and soup.title.string:
        title = soup.title.string.strip()
    meta_title = soup.find("meta", property="og:title") or soup.find("meta", attrs={"name": "title"})
    if not title and meta_title:
        try:
            content = meta_title.get("content")  # type: ignore
            if content:
                title = str(content).strip()
        except AttributeError:
            pass

    # Try typical article containers
    candidates = []
    for tag in ["article", "main"]:
        for el in soup.find_all(tag):
            candidates.append(el.get_text(separator=" ", strip=True))
    if not candidates:
        # Fallback to paragraphs
        candidates = [" ".join(p.get_text(separator=" ", strip=True) for p in soup.find_all("p"))]

    # Select the longest text block
    text = max(candidates, key=len) if candidates else ""
    text = re.sub(r"\s+", " ", text).strip()

    # Excerpt
    excerpt = None
    meta_desc = soup.find("meta", attrs={"name": "description"}) or soup.find("meta", property="og:description")
    if meta_desc:
        try:
            content = meta_desc.get("content")  # type: ignore
            if content:
                excerpt = str(content).strip()
        except AttributeError:
            pass
    if not excerpt:
        excerpt = " ".join(text.split()[:50]) + ("..." if len(text.split()) > 50 else "")

    return {"title": title, "text": text, "excerpt": excerpt}


def score_article(title: Optional[str], text: str, domain: Optional[str]) -> Tuple[float, List[str], Dict[str, Any]]:
    flags = []
    indicators = {}

    # Word count
    words = text.split()
    word_count = len(words)
    indicators["word_count"] = word_count
    if word_count < 150:
        flags.append("Very short content — may lack context.")

    # Clickbait detection
    haystack = (" " + (title or "") + " " + " ".join(words[:50])).lower()
    clickbait_hits = [p for p in CLICKBAIT_PHRASES if p in haystack]
    indicators["clickbait_hits"] = clickbait_hits
    if clickbait_hits:
        flags.append(f"Possible clickbait phrases: {', '.join(clickbait_hits)}.")

    # Excessive punctuation / casing
    exclamations = haystack.count("!")
    questions = haystack.count("?")
    all_caps_ratio = 0.0
    if title:
        caps_tokens = [t for t in re.findall(r"[A-Z]{3,}", title) if t not in ("USA", "UK", "UAE", "NATO")]
        if words:
            all_caps_ratio = len(caps_tokens) / max(1, len(title.split()))
    indicators["exclamations"] = exclamations
    indicators["questions"] = questions
    indicators["all_caps_ratio"] = round(all_caps_ratio, 3)
    if exclamations >= 3 or questions >= 3 or all_caps_ratio > 0.3:
        flags.append("Sensational punctuation or casing in the title.")

    # Source prior
    prior = 0.5
    if domain:
        parts = domain.split(".")
        base = ".".join(parts[-2:]) if len(parts) >= 2 else domain
        prior = KNOWN_SOURCES.get(base, 0.55)
        indicators["source_base"] = base
        indicators["source_prior"] = prior

    # Heuristic scoring
    score = prior
    score -= 0.15 * min(1, len(clickbait_hits))  # Penalize clickbait
    if exclamations >= 3 or questions >= 3:
        score -= 0.1
    if all_caps_ratio > 0.3:
        score -= 0.05
    if word_count < 150:
        score -= 0.1

    score = float(max(0.0, min(1.0, round(score, 3))))  # Clamp 0-1
    return score, flags, indicators


@app.post("/analyze", response_model=AnalyzeResponse)
def analyze(body: AnalyzeRequest):
    if not body.url and not body.text:
        raise HTTPException(status_code=400, detail="Provide either 'url' or 'text'.")

    title = None
    text = ""
    excerpt = None
    domain = None

    if body.url:
        try:
            resp = requests.get(str(body.url), timeout=12)
            resp.raise_for_status()
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Failed to fetch URL: {e}")

        parsed = extract_text_from_html(resp.text)
        title = parsed["title"]
        text = parsed["text"]
        excerpt = parsed["excerpt"]
        domain = urlparse(str(body.url)).netloc
    else:
        text = body.text or ""
        excerpt = " ".join(text.split()[:50]) + ("..." if len(text.split()) > 50 else "")

    # Ensure text is never None
    safe_text = text or ""
    score, flags, indicators = score_article(title, safe_text, domain)
    return AnalyzeResponse(
        title=title,
        source_domain=domain,
        word_count=len(text.split()) if text else 0,
        credibility_score=score,
        flags=flags,
        indicators=indicators,
        excerpt=excerpt
    )
