Task3: Integration
