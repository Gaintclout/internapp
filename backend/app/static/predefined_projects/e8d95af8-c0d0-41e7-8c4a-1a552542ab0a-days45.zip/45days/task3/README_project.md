# Fake News Detector – Backend (FastAPI)

## Quick start
```bash
# 1) Create & activate a venv (optional but recommended)
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate

# 2) Install dependencies
pip install -r requirements.txt

# 3) Run the server
uvicorn app.main:app --reload --port 8000
```

The API exposes:
- `POST /analyze` – Analyze a URL or raw text.
  - Body: `{ "url": "https://example.com/some-article" }` **or** `{ "text": "paste article text" }`
  - Response: structured JSON with a credibility score, flags, and extracted metadata.

## Notes
- The analyzer is deliberately lightweight and heuristic-based (no large models).
- If a URL is provided, the service will fetch the page and extract text from common article tags using BeautifulSoup.