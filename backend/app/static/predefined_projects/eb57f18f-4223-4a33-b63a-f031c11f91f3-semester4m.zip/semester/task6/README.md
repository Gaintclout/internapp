Task 6: Placeholder
