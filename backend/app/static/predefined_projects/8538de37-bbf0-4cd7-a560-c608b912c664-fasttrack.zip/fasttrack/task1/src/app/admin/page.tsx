
'use client';
import { useState, useEffect } from 'react';
import AuthLayout from '@/components/auth-layout';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MoreHorizontal, Trash2, Eye } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useAppState } from '@/hooks/use-app-state';
import { getUsersFlow, User, deleteUserFlow } from '@/ai/flows/user-flow';
import { format } from 'date-fns';
import Image from 'next/image';
import { useToast } from '@/hooks/use-toast';

export default function AdminPage() {
    const { attempts, clearAllData } = useAppState();
    const [users, setUsers] = useState<User[]>([]);
    const [isMounted, setIsMounted] = useState(false);
    const { toast } = useToast();

    async function fetchUsers() {
        const userList = await getUsersFlow();
        setUsers(userList);
    }
    
    useEffect(() => {
        setIsMounted(true);
        fetchUsers();
    }, []); 

    useEffect(() => {
        // Refreshes when a new attempt is made (which could be a registration)
        // This is a bit of a hack for the prototype, in a real app you'd likely use websockets or server-sent events
        if (isMounted) {
            fetchUsers();
        }
    }, [attempts, isMounted]);

    const handleDeleteUser = async (userId: string) => {
        try {
            await deleteUserFlow(userId);
            toast({
                title: 'User Deleted',
                description: 'The user has been successfully deleted.',
            });
            fetchUsers(); // Refresh the user list
        } catch (error) {
            console.error('Failed to delete user:', error);
            toast({
                variant: 'destructive',
                title: 'Deletion Failed',
                description: 'Could not delete the user.',
            });
        }
    };


    const fakeAttempts = attempts.filter(attempt => !attempt.analysis?.isReal);
    
    const chartData = Array.from({ length: 7 }, (_, i) => {
        const d = new Date();
        d.setDate(d.getDate() - i);
        return {
          date: format(d, 'eee'),
          logins: 0,
          fakes: 0,
        };
      }).reverse();

    attempts.forEach(attempt => {
        const attemptDate = new Date(); // In a real app, use the attempt's timestamp
        const dayData = chartData.find(d => d.date === format(attemptDate, 'eee'));
        if (dayData) {
            if(attempt.found) dayData.logins++;
            if(!attempt.analysis?.isReal) dayData.fakes++;
        }
    });
    
    if (!isMounted) {
        return <AuthLayout><div>Loading...</div></AuthLayout>;
    }


  return (
    <AuthLayout>
        <div className="flex justify-end mb-4">
            <AlertDialog>
                <AlertDialogTrigger asChild>
                    <Button variant="destructive">
                        <Trash2 className="mr-2 h-4 w-4" />
                        Clear All Data
                    </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                    <AlertDialogHeader>
                    <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                        This action will delete all registered users and login attempts. This cannot be undone.
                    </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={() => {
                        clearAllData();
                        setUsers([]);
                    }}>Continue</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
      <Tabs defaultValue="all-users" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="all-users">All Users ({users.length})</TabsTrigger>
          <TabsTrigger value="fake-attempts">Fake Attempts ({fakeAttempts.length})</TabsTrigger>
          <TabsTrigger value="stats">Stats</TabsTrigger>
        </TabsList>

        <TabsContent value="all-users">
          <Card>
            <CardHeader>
              <CardTitle>All Users</CardTitle>
              <CardDescription>Manage all registered users.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Face Data</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {users.map(user => (
                        <TableRow key={user.id}>
                            <TableCell className="flex items-center gap-2">
                                <Avatar>
                                    <AvatarImage src={user.faceDataUri} alt={user.name} />
                                    <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                                </Avatar>
                                {user.name}
                            </TableCell>
                            <TableCell>{user.email}</TableCell>
                            <TableCell>
                                <Badge variant={user.faceDataUri ? 'default' : 'secondary'}>{user.faceDataUri ? 'Available' : 'Not Set'}</Badge>
                            </TableCell>
                            <TableCell className="text-right">
                               <Dialog>
                                    <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                                <Button variant="ghost" size="icon"><MoreHorizontal /></Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent>
                                            <DialogTrigger asChild>
                                                <DropdownMenuItem><Eye className="mr-2 h-4 w-4"/>View Face Data</DropdownMenuItem>
                                            </DialogTrigger>
                                            <AlertDialog>
                                                <AlertDialogTrigger asChild>
                                                    <DropdownMenuItem className="text-red-500" onSelect={(e) => e.preventDefault()}><Trash2 className="mr-2 h-4 w-4"/>Delete User</DropdownMenuItem>
                                                </AlertDialogTrigger>
                                                <AlertDialogContent>
                                                    <AlertDialogHeader>
                                                    <AlertDialogTitle>Delete {user.name}?</AlertDialogTitle>
                                                    <AlertDialogDescription>
                                                        This action cannot be undone. This will permanently delete the user and their associated data.
                                                    </AlertDialogDescription>
                                                    </AlertDialogHeader>
                                                    <AlertDialogFooter>
                                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                                    <AlertDialogAction onClick={() => handleDeleteUser(user.id)}>Delete</AlertDialogAction>
                                                    </AlertDialogFooter>
                                                </AlertDialogContent>
                                            </AlertDialog>
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                     <DialogContent>
                                        <DialogHeader>
                                        <DialogTitle>Face Data for {user.name}</DialogTitle>
                                        <DialogDescription>
                                            This is the captured image used for facial recognition.
                                        </DialogDescription>
                                        </DialogHeader>
                                        <div className="mt-4">
                                            <Image src={user.faceDataUri} alt={`Face of ${user.name}`} width={400} height={400} className="rounded-lg object-cover" />
                                        </div>
                                    </DialogContent>
                               </Dialog>
                            </TableCell>
                        </TableRow>
                    ))}
                    {users.length === 0 && (
                        <TableRow>
                            <TableCell colSpan={4} className="text-center h-24">No users registered yet.</TableCell>
                        </TableRow>
                    )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fake-attempts">
            <Card>
                <CardHeader>
                    <CardTitle>Fake Attempts</CardTitle>
                    <CardDescription>Review all flagged fake login attempts.</CardDescription>
                </CardHeader>
                <CardContent>
                     <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Date & Time</TableHead>
                                <TableHead>Emotion</TableHead>
                                <TableHead>Liveness Confidence</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {fakeAttempts.map((attempt, index) => (
                                <TableRow key={index}>
                                    <TableCell>{format(new Date(), 'PPpp')}</TableCell>
                                    <TableCell>{attempt.analysis?.emotion}</TableCell>
                                    <TableCell>
                                        <Badge variant="destructive">{((attempt.analysis?.livenessConfidence ?? 0) * 100).toFixed(0)}%</Badge>
                                    </TableCell>
                                </TableRow>
                            ))}
                             {fakeAttempts.length === 0 && (
                                <TableRow>
                                    <TableCell colSpan={3} className="text-center h-24">No fake attempts recorded.</TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                     </Table>
                </CardContent>
            </Card>
        </TabsContent>
        
        <TabsContent value="stats">
            <Card>
                <CardHeader>
                    <CardTitle>Login Statistics</CardTitle>
                    <CardDescription>Daily and weekly login activity.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="h-[400px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={chartData}>
                                <XAxis dataKey="date" stroke="#888888" fontSize={12} />
                                <YAxis stroke="#888888" fontSize={12} />
                                <Tooltip
                                    contentStyle={{
                                    backgroundColor: 'hsl(var(--background))',
                                    borderColor: 'hsl(var(--border))'
                                    }}
                                />
                                <Legend />
                                <Bar dataKey="logins" fill="hsl(var(--primary))" name="Successful Logins" radius={[4, 4, 0, 0]} />
                                <Bar dataKey="fakes" fill="hsl(var(--destructive))" name="Fake Attempts" radius={[4, 4, 0, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </CardContent>
            </Card>
        </TabsContent>
      </Tabs>
    </AuthLayout>
  );
}
