'use client';
import AuthLayout from '@/components/auth-layout';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ShieldAlert, CheckCircle, UserCircle, Smile, Webcam } from 'lucide-react';
import Image from 'next/image';
import { useAppState } from '@/hooks/use-app-state';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { LoginUserOutput } from '@/ai/flows/login-flow';
import { format } from 'date-fns';

export default function AlertPage() {
    const { attempts } = useAppState();
    const router = useRouter();
    const [isMounted, setIsMounted] = useState(false);
    const [latestFakeAttempt, setLatestFakeAttempt] = useState<LoginUserOutput | null>(null);

    useEffect(() => {
        setIsMounted(true);
    }, []);

    useEffect(() => {
        if (isMounted) {
            const fakeAttempt = [...attempts].reverse().find(att => att.analysis && !att.analysis.isReal);
            if (fakeAttempt) {
                setLatestFakeAttempt(fakeAttempt);
            }
        }
    }, [attempts, isMounted]);

    if (!isMounted) {
        return (
             <AuthLayout>
                <div className="flex flex-col items-center justify-center h-full text-center">
                    <CheckCircle className="h-16 w-16 text-green-500 mb-4" />
                    <h2 className="text-2xl font-bold mb-2">All Clear!</h2>
                    <p className="text-muted-foreground">There are no new security alerts for your account.</p>
                     <Button onClick={() => router.push('/inbox')} className="mt-6">Go to Inbox</Button>
                </div>
            </AuthLayout>
        );
    }

    if (!latestFakeAttempt) {
        return (
             <AuthLayout>
                <div className="flex flex-col items-center justify-center h-full text-center">
                    <CheckCircle className="h-16 w-16 text-green-500 mb-4" />
                    <h2 className="text-2xl font-bold mb-2">All Clear!</h2>
                    <p className="text-muted-foreground">There are no new security alerts for your account.</p>
                     <Button onClick={() => router.push('/inbox')} className="mt-6">Go to Inbox</Button>
                </div>
            </AuthLayout>
        );
    }
    
    const { analysis } = latestFakeAttempt;

  return (
    <AuthLayout>
      <div className="space-y-6">
        <Alert variant="destructive">
          <ShieldAlert className="h-4 w-4" />
          <AlertTitle>Intrusion Warning!</AlertTitle>
          <AlertDescription>
            An unrecognized or fake face attempted to log into your account. Please review the details below.
          </AlertDescription>
        </Alert>

        <Card>
          <CardHeader>
            <CardTitle>Attempt Details</CardTitle>
          </CardHeader>
          <CardContent className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <UserCircle className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Date / Time</p>
                  <p className="font-semibold">{format(new Date(), 'PPpp')}</p>
                </div>
              </div>
               <div className="flex items-center gap-3">
                <Smile className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Detected Emotion</p>
                  <p className="font-semibold">{analysis?.emotion}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Webcam className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Liveness Confidence</p>
                  <p className="font-semibold text-red-500">{((analysis?.livenessConfidence ?? 0) * 100).toFixed(0)}%</p>
                </div>
              </div>
            </div>
            <div>
              <p className="text-sm font-medium mb-2">Snapshot of Attempt</p>
              <div className="aspect-video bg-muted rounded-lg overflow-hidden border">
                <Image
                  src={latestFakeAttempt.analysis?.isReal === false ? latestFakeAttempt.faceDataUri: "https://placehold.co/600x400.png"}
                  alt="Snapshot of face"
                  data-ai-hint="face scan"
                  width={600}
                  height={400}
                  className="object-cover w-full h-full"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button size="lg" onClick={() => router.push('/inbox')}>
            <CheckCircle className="mr-2 h-4 w-4" />
            Mark as Reviewed
          </Button>
        </div>
      </div>
    </AuthLayout>
  );
}
