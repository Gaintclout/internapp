
'use client';

import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import PublicLayout from '@/components/public-layout';
import WebcamFeed from '@/components/webcam-feed';
import { LogIn, RotateCcw, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { loginUser } from '@/ai/flows/login-flow';
import { useAppState } from '@/hooks/use-app-state';

export default function FaceLoginPage() {
  const [detectionStatus, setDetectionStatus] = useState<'neutral' | 'match' | 'mismatch'>('neutral');
  const [isLoading, setIsLoading] = useState(false);
  const webcamRef = useRef<HTMLVideoElement>(null);
  const { toast } = useToast();
  const router = useRouter();
  const { setUser, addAttempt } = useAppState();

  const handleLogin = async () => {
    if (!webcamRef.current) {
        toast({
            variant: 'destructive',
            title: 'Webcam not ready',
            description: 'Please wait for the webcam to initialize.',
        });
        return;
    }

    if (webcamRef.current.videoWidth === 0 || webcamRef.current.videoHeight === 0) {
        toast({
            variant: 'destructive',
            title: 'Webcam Error',
            description: 'Could not capture image. Please ensure the webcam is working.',
        });
        return;
    }

    setIsLoading(true);
    setDetectionStatus('neutral');

    const canvas = document.createElement('canvas');
    canvas.width = webcamRef.current.videoWidth;
    canvas.height = webcamRef.current.videoHeight;
    canvas.getContext('2d')?.drawImage(webcamRef.current, 0, 0);
    const faceDataUri = canvas.toDataURL('image/jpeg');

    try {
      const result = await loginUser({ faceDataUri });
      addAttempt(result);

      if (result.found && result.user) {
        setDetectionStatus('match');
        toast({
          title: 'Login Successful',
          description: `Welcome back, ${result.user.name}!`,
        });
        setUser(result.user);
        router.push('/inbox');
      } else if (result.analysis && !result.analysis.isReal) {
         setDetectionStatus('mismatch');
         toast({
            variant: 'destructive',
            title: 'Login Failed',
            description: 'Fake attempt detected. This incident will be reported.',
         });
         router.push('/alert');
      } else {
        setDetectionStatus('mismatch');
        toast({
            variant: 'destructive',
            title: 'Login Failed',
            description: 'No matching user found. Please try again.',
        });
      }
    } catch (error) {
        console.error(error);
        setDetectionStatus('mismatch');
        toast({
            variant: 'destructive',
            title: 'An error occurred',
            description: 'Something went wrong during login. Please try again.',
        });
    } finally {
        setIsLoading(false);
    }
  };

  const handleRetry = () => {
    setDetectionStatus('neutral');
  };

  return (
    <PublicLayout>
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-2xl font-headline">Face Login</CardTitle>
          <CardDescription>Position your face within the frame to log in.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <WebcamFeed ref={webcamRef} detectionStatus={detectionStatus} />
        </CardContent>
        <CardFooter className="flex flex-col gap-4">
          <Button onClick={handleLogin} className="w-full" size="lg" disabled={isLoading}>
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <LogIn className="mr-2 h-4 w-4" />}
            {isLoading ? 'Analyzing...' : 'Login'}
          </Button>
          <Button onClick={handleRetry} variant="outline" className="w-full" disabled={isLoading}>
            <RotateCcw className="mr-2 h-4 w-4" />
            Retry
          </Button>
        </CardFooter>
      </Card>
    </PublicLayout>
  );
}
