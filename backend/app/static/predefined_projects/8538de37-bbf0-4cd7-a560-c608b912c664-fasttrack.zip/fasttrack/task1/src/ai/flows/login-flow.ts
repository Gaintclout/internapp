
'use server';
/**
 * @fileOverview A user login flow.
 *
 * - loginUser - A function that handles the user login process.
 * - LoginUserInput - The input type for the loginUser function.
 * - LoginUserOutput - The return type for the loginUser function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'zod';
import { UserSchema, FaceAnalysisSchema } from './types';
import { getUsersFlow } from './user-flow';
import { analyzeFaceFlow } from './face-analysis-flow';

const LoginUserInputSchema = z.object({
    faceDataUri: z.string().describe(
        "A photo of the user's face, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});

export type LoginUserInput = z.infer<typeof LoginUserInputSchema>;

const LoginUserOutputSchema = z.object({
    user: UserSchema.optional(),
    found: z.boolean().describe('Whether a matching user was found.'),
    analysis: FaceAnalysisSchema.optional().describe('Analysis of the face provided for login.'),
});

export type LoginUserOutput = z.infer<typeof LoginUserOutputSchema>;

export async function loginUser(input: LoginUserInput): Promise<LoginUserOutput> {
    return loginUserFlow(input);
}

const loginPrompt = ai.definePrompt({
    name: 'loginPrompt',
    input: {
        schema: z.object({
            loginFace: z.string(),
            users: z.array(UserSchema),
        }),
    },
    output: {
        schema: z.object({
            bestMatchUserId: z.string().optional(),
        })
    },
    prompt: `
        You are a face recognition expert. Compare the provided login face image with the list of registered user faces.
        Identify the user with the highest similarity score.

        Login attempt face: {{media url=loginFace}}
        
        Registered Users:
        {{#each users}}
        - User ID: {{this.id}}
          User Name: {{this.name}}
          User Face: {{media url=this.faceDataUri}}
        {{/each}}
        
        Based on your analysis, determine the ID of the best matching user.
        If no user is a clear match, do not return a user ID.
    `,
});


const loginUserFlow = ai.defineFlow(
    {
        name: 'loginUserFlow',
        inputSchema: LoginUserInputSchema,
        outputSchema: LoginUserOutputSchema,
    },
    async (input) => {
        console.log('Attempting to log in user with face data.');

        const [users, analysis] = await Promise.all([
            getUsersFlow(),
            analyzeFaceFlow({faceDataUri: input.faceDataUri})
        ]);
        
        if (users.length === 0) {
            console.log("No users registered yet.");
            return { found: false, analysis };
        }

        if (!analysis.isReal) {
            console.log("Fake attempt detected.");
            return { found: false, analysis };
        }

        const { output } = await loginPrompt({
            loginFace: input.faceDataUri,
            users: users,
        });

        if (!output?.bestMatchUserId) {
            console.log("No matching user found by AI.");
            return { found: false, analysis };
        }
        
        const matchedUser = users.find(u => u.id === output.bestMatchUserId);

        if (matchedUser) {
            console.log("Found matching user:", matchedUser.name);
            return {
                found: true,
                user: matchedUser,
                analysis,
            };
        }
        
        console.log("Best match user ID from AI was not in the user list.");
        return { found: false, analysis };
    }
);
