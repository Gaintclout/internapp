/**
 * @fileOverview Shared data types for Genkit flows.
 */

import {z} from 'zod';

export const UserSchema = z.object({
  id: z.string().describe('The unique ID of the user.'),
  name: z.string().describe('The name of the user.'),
  email: z.string().email().describe('The email of the user.'),
  faceDataUri: z
    .string()
    .describe(
      "A photo of the user's face, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});

export const RegisterUserInputSchema = UserSchema.omit({ id: true }).extend({
    password: z.string().min(8).describe('The user\'s password.'),
});

export const FaceAnalysisSchema = z.object({
  isReal: z.boolean().describe("Whether the face is determined to be a real, live person and not a photo or mask."),
  emotion: z.enum(["Smiling", "Sad", "Angry", "Neutral", "Surprised", "Happy"]).describe("The dominant emotion detected on the face."),
  livenessConfidence: z.number().min(0).max(1).describe("The confidence score (0-1) for the liveness detection."),
});
