
'use server';
/**
 * @fileOverview A flow for analyzing a face image.
 *
 * - analyzeFaceFlow - Analyzes a face for liveness and emotion.
 */
import {ai} from '@/ai/genkit';
import {z} from 'zod';
import { FaceAnalysisSchema } from './types';

const FaceAnalysisInputSchema = z.object({
    faceDataUri: z.string().describe(
        "A photo of a face, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});

export type FaceAnalysisInput = z.infer<typeof FaceAnalysisInputSchema>;
export type FaceAnalysisOutput = z.infer<typeof FaceAnalysisSchema>;

export async function analyzeFaceFlow(input: FaceAnalysisInput): Promise<FaceAnalysisOutput> {
    return faceAnalysisFlow(input);
}

const analysisPrompt = ai.definePrompt({
    name: 'faceAnalysisPrompt',
    input: { schema: FaceAnalysisInputSchema },
    output: { schema: FaceAnalysisSchema },
    prompt: `
        You are a security expert specializing in facial analysis for authentication systems.
        Analyze the provided image to determine if it's a real, live person.
        Check for signs of a "fake attempt", such as a photo of a screen, a printed photo, or a mask.
        Also, determine the primary emotion of the person in the image.

        Image to analyze: {{media url=faceDataUri}}

        Set 'isReal' to false if you suspect it's not a live person.
        Provide a confidence score for your liveness detection.
    `,
});

const faceAnalysisFlow = ai.defineFlow(
    {
        name: 'faceAnalysisFlow',
        inputSchema: FaceAnalysisInputSchema,
        outputSchema: FaceAnalysisSchema,
    },
    async (input) => {
        console.log('Analyzing face for liveness and emotion...');
        const { output } = await analysisPrompt(input);
        
        if (!output) {
            throw new Error("Face analysis failed to produce an output.");
        }
        
        console.log('Analysis complete:', output);
        return output;
    }
);
