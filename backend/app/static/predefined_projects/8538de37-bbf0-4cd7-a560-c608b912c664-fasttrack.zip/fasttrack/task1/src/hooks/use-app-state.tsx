'use client';

import { User } from '@/ai/flows/user-flow';
import { LoginUserOutput } from '@/ai/flows/login-flow';
import React, { createContext, useContext, useState, ReactNode } from 'react';

interface AppState {
  user: User | null;
  setUser: (user: User | null) => void;
  attempts: LoginUserOutput[];
  addAttempt: (attempt: LoginUserOutput) => void;
  clearAllData: () => void;
}

const AppStateContext = createContext<AppState | undefined>(undefined);

export const AppStateProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [attempts, setAttempts] = useState<LoginUserOutput[]>([]);
  
  const addAttempt = (attempt: LoginUserOutput) => {
    setAttempts(prev => [...prev, attempt]);
  };
  
  const clearAllData = () => {
    setUser(null);
    setAttempts([]);
  };

  return (
    <AppStateContext.Provider value={{ user, setUser, attempts, addAttempt, clearAllData }}>
      {children}
    </AppStateContext.Provider>
  );
};

export const useAppState = () => {
  const context = useContext(AppStateContext);
  if (context === undefined) {
    throw new Error('useAppState must be used within an AppStateProvider');
  }
  return context;
};
