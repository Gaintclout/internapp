
'use server';
/**
 * @fileOverview User management flows.
 *
 * - registerUser - A function that handles user registration.
 */

import {ai} from '@/ai/genkit';
import {z} from 'zod';
import { RegisterUserInputSchema, UserSchema } from './types';

export type RegisterUserInput = z.infer<typeof RegisterUserInputSchema>;
export type User = z.infer<typeof UserSchema>;

// In-memory store for users for prototype purposes.
let users: User[] = [];

export async function registerUser(input: RegisterUserInput): Promise<User> {
    return registerUserFlow(input);
}

const registerUserFlow = ai.defineFlow(
  {
    name: 'registerUserFlow',
    inputSchema: RegisterUserInputSchema,
    outputSchema: UserSchema,
  },
  async (input) => {
    console.log('Registering user', input.name);
    
    const existingUser = users.find(u => u.email === input.email);
    if (existingUser) {
        throw new Error('User with this email already exists.');
    }

    const user: User = {
        id: `user-${Date.now()}`,
        name: input.name,
        email: input.email,
        faceDataUri: input.faceDataUri,
    };

    users.push(user);
    console.log('Current users:', users.map(u => u.name));

    return user;
  }
);

// Helper flow to get all registered users (for login flow)
export async function getUsersFlow(): Promise<User[]> {
    return getUsersFlowInternal();
};

const getUsersFlowInternal = ai.defineFlow({
    name: 'getUsersFlow',
    outputSchema: z.array(UserSchema),
}, async () => {
    return users;
});

export async function deleteUserFlow(userId: string): Promise<boolean> {
    return deleteUserFlowInternal(userId);
}

const deleteUserFlowInternal = ai.defineFlow({
    name: 'deleteUserFlow',
    inputSchema: z.string(),
    outputSchema: z.boolean(),
}, async (userId) => {
    const initialLength = users.length;
    users = users.filter(u => u.id !== userId);
    console.log(`User with ID ${userId} deleted. Current users:`, users.map(u => u.name));
    return users.length < initialLength;
});
