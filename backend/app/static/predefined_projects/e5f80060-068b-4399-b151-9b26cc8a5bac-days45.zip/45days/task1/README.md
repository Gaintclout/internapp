Task1: Frontend UI.
