Task2: Backend core.
