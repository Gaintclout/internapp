import { SettingsClientPage } from './settings-client-page';
import { emails } from '@/lib/data';
import { suggestKeywords } from '@/ai/flows/suggest-keywords';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

async function handleSuggestKeywords() {
  'use server';
  try {
    const emailHistory = emails.map(e => e.body).join('\n\n');
    const result = await suggestKeywords({ emailHistory });
    return result.keywords;
  } catch (error) {
    console.error(error);
    return [];
  }
}

export default function SettingsPage() {
  const initialKeywords = ['viagra', 'lottery', 'free money', 'winner', 'prince', 'claim prize'];
  const initialIps = ['192.168.1.101', '203.0.113.55', '98.51.100.3', '104.28.23.78'];

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tight">Settings</h2>
            <p className="text-muted-foreground">
                Manage your spam filters and blacklists.
            </p>
        </div>
        <SettingsClientPage
            suggestKeywordsAction={handleSuggestKeywords}
            initialKeywords={initialKeywords}
            initialIps={initialIps}
        />
    </div>
  );
}
