'use client';
import { useState, useTransition } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Trash2, Sparkles, Loader2, PlusCircle, Check } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

type SettingsClientPageProps = {
    suggestKeywordsAction: () => Promise<string[]>;
    initialKeywords: string[];
    initialIps: string[];
};

function FilterManager({ title, description, items, onAdd, onRemove }: {
    title: string;
    description: string;
    items: string[];
    onAdd: (item: string) => void;
    onRemove: (item: string) => void;
}) {
    const [newItem, setNewItem] = useState('');

    const handleAdd = (e: React.FormEvent) => {
        e.preventDefault();
        if(newItem.trim()) {
            onAdd(newItem.trim());
            setNewItem('');
        }
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent>
                <form onSubmit={handleAdd} className="flex items-center gap-2 mb-4">
                    <Input
                        placeholder={`New ${title.toLowerCase().slice(0,-1)}...`}
                        value={newItem}
                        onChange={(e) => setNewItem(e.target.value)}
                    />
                    <Button type="submit"><PlusCircle className="mr-2 h-4 w-4" /> Add</Button>
                </form>
                <div className="flex flex-wrap gap-2">
                    {items.length > 0 ? items.map(item => (
                        <Badge key={item} variant="secondary" className="animate-in fade-in-0 zoom-in-95 text-sm font-normal pl-3 pr-1 py-1">
                            {item}
                            <button onClick={() => onRemove(item)} className="ml-2 rounded-full hover:bg-muted-foreground/20 p-0.5">
                                <Trash2 className="h-3 w-3" />
                                <span className="sr-only">Remove {item}</span>
                            </button>
                        </Badge>
                    )) : <p className="text-sm text-muted-foreground">No items in this list.</p>}
                </div>
            </CardContent>
        </Card>
    )
}

export function SettingsClientPage({ suggestKeywordsAction, initialKeywords, initialIps }: SettingsClientPageProps) {
    const [keywords, setKeywords] = useState<string[]>(initialKeywords);
    const [blacklistedIps, setBlacklistedIps] = useState<string[]>(initialIps);
    const [suggestedKeywords, setSuggestedKeywords] = useState<string[]>([]);
    
    const [isPending, startTransition] = useTransition();
    const { toast } = useToast();

    const addKeyword = (keyword: string) => {
        if (!keywords.includes(keyword)) {
            setKeywords([...keywords, keyword]);
        }
    };

    const removeKeyword = (keyword: string) => {
        setKeywords(keywords.filter(k => k !== keyword));
    };

    const addIp = (ip: string) => {
        if (!blacklistedIps.includes(ip)) {
            setBlacklistedIps([...blacklistedIps, ip]);
        }
    };

    const removeIp = (ip: string) => {
        setBlacklistedIps(blacklistedIps.filter(i => i !== ip));
    };
    
    const onSuggestKeywords = () => {
        startTransition(async () => {
            const suggestions = await suggestKeywordsAction();
            if (suggestions && suggestions.length > 0) {
                setSuggestedKeywords(suggestions);
            } else {
                 toast({
                    title: 'AI Suggestions Failed',
                    description: 'Could not fetch keyword suggestions at this time.',
                    variant: 'destructive',
                });
            }
        });
    };

    const addSuggestedKeyword = (keyword: string) => {
        addKeyword(keyword);
        setSuggestedKeywords(suggestedKeywords.filter(k => k !== keyword));
    }

    return (
        <Tabs defaultValue="keywords" className="space-y-4">
            <TabsList>
                <TabsTrigger value="keywords">Keyword Filters</TabsTrigger>
                <TabsTrigger value="ip-blacklist">IP Blacklist</TabsTrigger>
            </TabsList>
            <TabsContent value="keywords" className="space-y-4">
                <FilterManager 
                    title="Keywords"
                    description="Emails containing these keywords will be marked as spam."
                    items={keywords}
                    onAdd={addKeyword}
                    onRemove={removeKeyword}
                />
                <Card>
                    <CardHeader>
                        <CardTitle>AI Keyword Suggestions</CardTitle>
                        <CardDescription>Let our AI suggest keywords based on common spam patterns.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Button onClick={onSuggestKeywords} disabled={isPending}>
                            {isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
                            Suggest Keywords
                        </Button>
                        {suggestedKeywords.length > 0 && (
                            <div className="mt-4 space-y-2">
                                <h4 className="font-medium">Click to add a suggestion:</h4>
                                <div className="flex flex-wrap gap-2">
                                    {suggestedKeywords.map(keyword => (
                                        <Button key={keyword} variant="outline" size="sm" onClick={() => addSuggestedKeyword(keyword)} className="animate-in fade-in-0 zoom-in-95">
                                            <PlusCircle className="mr-2 h-4 w-4"/>
                                            {keyword}
                                        </Button>
                                    ))}
                                </div>
                            </div>
                        )}
                    </CardContent>
                </Card>
            </TabsContent>
            <TabsContent value="ip-blacklist">
                 <FilterManager 
                    title="IP Addresses"
                    description="Emails from these IP addresses will be blocked."
                    items={blacklistedIps}
                    onAdd={addIp}
                    onRemove={removeIp}
                />
            </TabsContent>
        </Tabs>
    );
}
