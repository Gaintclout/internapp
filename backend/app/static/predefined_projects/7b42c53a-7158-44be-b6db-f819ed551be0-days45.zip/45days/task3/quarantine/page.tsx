import { emails } from '@/lib/data';
import { EmailList } from '@/components/email/email-list';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default async function QuarantinePage() {
  const spamEmails = emails.filter((email) => email.isSpam);

  return (
    <div className="flex h-full flex-col">
      <header className="border-b bg-card p-4">
        <h1 className="text-2xl font-bold tracking-tight">Quarantine</h1>
        <p className="text-sm text-muted-foreground">
          {spamEmails.length} emails flagged as potential spam.
        </p>
      </header>
      <div className="flex-1 overflow-auto">
        <div className="p-4">
            <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Review Required</AlertTitle>
                <AlertDescription>
                    Emails in this folder are suspected to be spam. Review them carefully before deleting. You can move legitimate emails back to your inbox.
                </AlertDescription>
            </Alert>
        </div>
        <EmailList emails={spamEmails} type="quarantine" />
      </div>
    </div>
  );
}
