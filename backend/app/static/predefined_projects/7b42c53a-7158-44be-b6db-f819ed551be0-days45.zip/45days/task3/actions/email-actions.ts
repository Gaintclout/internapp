'use server';

import { reportMisclassifiedEmail } from '@/ai/flows/report-misclassified-email';

export async function handleReportAction(emailContent: string, isSpam: boolean) {
  try {
    const result = await reportMisclassifiedEmail({ emailContent, isSpam });
    return result;
  } catch (error) {
    console.error(error);
    return { success: false, message: 'Failed to report email.' };
  }
}

export async function blockIpAddress(ip: string) {
    try {
        // In a real application, you would add this IP to a persistent blacklist.
        // For this example, we'll just log it to the console.
        console.log(`Blocked IP address: ${ip}`);
        return { success: true, message: `IP address ${ip} has been blocked.` };
    } catch (error) {
        console.error('Failed to block IP:', error);
        return { success: false, message: 'Failed to block IP address.' };
    }
}
