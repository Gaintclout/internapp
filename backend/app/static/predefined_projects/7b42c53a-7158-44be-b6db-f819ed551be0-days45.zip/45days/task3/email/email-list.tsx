'use client';

import { useTransition, useState, useEffect } from 'react';
import type { Email } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Inbox, Loader2, ShieldAlert, Trash2, Ban, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { handleReportAction, blockIpAddress } from '@/app/actions/email-actions';

function EmailActions({ email, type }: { email: Email; type: 'inbox' | 'quarantine' }) {
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();

  const handleReportAsSpam = () => {
    startTransition(async () => {
      const result = await handleReportAction(email.body, true);
      toast({
        title: result.success ? 'Reported as Spam' : 'Error',
        description: result.message,
        variant: result.success ? 'default' : 'destructive',
      });
    });
  };

  const handleMoveToInbox = () => {
    startTransition(async () => {
      const result = await handleReportAction(email.body, false);
      toast({
        title: result.success ? 'Moved to Inbox' : 'Error',
        description: result.message,
        variant: result.success ? 'default' : 'destructive',
      });
    });
  };
  
  const handleDelete = () => {
    toast({
        title: 'Email Deleted',
        description: 'The email has been moved to the trash.',
    });
  }

  const handleBlockIp = () => {
    startTransition(async () => {
        const result = await blockIpAddress(email.ipAddress);
        toast({
            title: result.success ? 'IP Blocked' : 'Error',
            description: result.message,
            variant: result.success ? 'default' : 'destructive',
        });
    });
  };

  return (
    <div className="flex items-center gap-2">
      {isPending && <Loader2 className="h-4 w-4 animate-spin" />}
      {type === 'inbox' ? (
        <Button variant="outline" size="sm" onClick={handleReportAsSpam} disabled={isPending}>
          <ShieldAlert className="h-4 w-4 mr-2" />
          Report Spam
        </Button>
      ) : (
        <Button variant="default" size="sm" onClick={handleMoveToInbox} disabled={isPending}>
          <Inbox className="h-4 w-4 mr-2" />
          Not Spam
        </Button>
      )}
       <Button variant="outline" size="sm" onClick={handleBlockIp} disabled={isPending}>
        <Ban className="h-4 w-4 mr-2" />
        Block IP
      </Button>
      <Button variant="outline" size="sm" onClick={handleDelete} disabled={isPending}>
        <Trash2 className="h-4 w-4 mr-2" />
        Delete
      </Button>
    </div>
  );
}


export function EmailList({ emails: initialEmails, type }: { emails: Email[]; type: 'inbox' | 'quarantine' }) {
  const [emails, setEmails] = useState<Email[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    try {
      // Ensure we have valid emails data
      if (Array.isArray(initialEmails)) {
        setEmails(initialEmails.filter(email => email && typeof email === 'object'));
      } else {
        console.error('Invalid emails data:', initialEmails);
        setError('Failed to load emails. Please try again later.');
      }
    } catch (err) {
      console.error('Error processing emails:', err);
      setError('An error occurred while loading emails.');
    } finally {
      setIsLoading(false);
    }
  }, [initialEmails]);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        <p className="mt-2 text-sm text-muted-foreground">Loading emails...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-64 p-4 text-center">
        <AlertCircle className="h-8 w-8 text-destructive mb-2" />
        <h3 className="text-lg font-medium">Something went wrong</h3>
        <p className="text-sm text-muted-foreground">{error}</p>
        <Button 
          variant="outline" 
          className="mt-4"
          onClick={() => window.location.reload()}
        >
          Retry
        </Button>
      </div>
    );
  }

  if (!emails || emails.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <Inbox className="h-10 w-10 text-muted-foreground mb-2" />
        <p className="text-sm text-muted-foreground">
          {type === 'inbox' ? 'Your inbox is empty.' : 'No emails in quarantine.'}
        </p>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-2">
      {emails.map((email) => (
        <Card key={email.id} className={cn("transition-all", !email.isRead && type === "inbox" && "bg-secondary/40")}>
            <Accordion type="single" collapsible>
                <AccordionItem value={email.id} className="border-b-0">
                    <AccordionTrigger className="p-4 text-left hover:no-underline [&[data-state=open]]:bg-muted/50">
                        <div className="flex items-start gap-4 w-full">
                            <Avatar className="hidden h-10 w-10 sm:flex">
                                <AvatarImage src={email.avatar} alt={email.from} data-ai-hint="person face" />
                                <AvatarFallback>{email.from.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div className="grid gap-1 flex-1 text-left">
                                <p className="text-sm font-medium leading-none">{email.from}</p>
                                <p className="text-sm text-muted-foreground truncate">{email.subject}</p>
                            </div>
                            <div className="ml-auto text-xs text-muted-foreground self-start">
                                {email.date}
                            </div>
                        </div>
                    </AccordionTrigger>
                    <AccordionContent>
                        <div className="p-4 bg-muted/50 text-sm text-muted-foreground flex justify-between items-center">
                            <div>From: {email.from} &lt;{email.fromEmail}&gt;</div>
                            <div>IP: {email.ipAddress}</div>
                        </div>
                        <Separator />
                        <div className="p-4 text-sm whitespace-pre-wrap">
                            {email.body}
                        </div>
                        <Separator />
                        <div className="p-4 flex justify-end">
                            <EmailActions email={email} type={type} />
                        </div>
                    </AccordionContent>
                </AccordionItem>
            </Accordion>
        </Card>
      ))}
    </div>
  );
}
