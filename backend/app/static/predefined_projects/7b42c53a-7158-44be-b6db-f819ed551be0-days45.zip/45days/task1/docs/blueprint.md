# **App Name**: MailGuard AI

## Core Features:

- AISpamDetection: AI-Powered Spam Detection: Trainable AI to analyze email content, headers, and sender information to identify potential spam with increased accuracy. The AI tool uses past decisions and domain expertise to route questionable mail to a quarantine folder.
- KeywordFilter: Keyword-Based Filtering: Customize filters to automatically classify emails containing specific words or phrases (e.g., misspellings of known brands) as spam.
- IPBlacklist: IP Address Blacklisting: Maintain a blacklist of known spam IP addresses, automatically blocking emails originating from those sources.
- ReportMisclassified: User Reporting: Provide a simple mechanism for users to report misclassified emails (spam in inbox, or vice-versa) to improve future filtering accuracy.
- Quarantine: Quarantine Folder: Automatically move suspected spam emails to a dedicated quarantine folder, allowing users to review and recover any legitimate emails that were misclassified.

## Style Guidelines:

- Primary color: A vibrant blue (#29ABE2) to evoke trust and security.
- Background color: A light blue (#E1F5FE), complementing the primary color.
- Accent color: A soft green (#8BC34A) for positive actions like 'approve' or 'whitelist'.
- Font pairing: 'Inter' for both headlines and body text, offering a clean and modern appearance (sans-serif).
- Simple, clear icons for spam/inbox actions.
- Clean and intuitive layout to prioritize quick access to email management functions.
- Subtle animations for filter updates or status changes.