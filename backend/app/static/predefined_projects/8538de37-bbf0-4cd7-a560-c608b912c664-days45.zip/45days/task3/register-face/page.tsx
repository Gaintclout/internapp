
'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import PublicLayout from '@/components/public-layout';
import WebcamFeed from '@/components/webcam-feed';
import { Camera, UserPlus, Loader2, CheckCircle } from 'lucide-react';
import { useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { registerUser } from '@/ai/flows/user-flow';
import { useRouter } from 'next/navigation';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const registerFormSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email." }),
  password: z.string().min(8, { message: "Password must be at least 8 characters." }),
});

export default function RegisterFacePage() {
  const [faceDataUri, setFaceDataUri] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const webcamRef = useRef<HTMLVideoElement>(null);
  const { toast } = useToast();
  const router = useRouter();

  const form = useForm<z.infer<typeof registerFormSchema>>({
    resolver: zodResolver(registerFormSchema),
    defaultValues: {
      name: "",
      email: "",
      password: "",
    },
  });

  const handleCaptureFace = () => {
    if (webcamRef.current) {
        if (webcamRef.current.videoWidth === 0 || webcamRef.current.videoHeight === 0) {
            toast({
                variant: 'destructive',
                title: 'Webcam Error',
                description: 'Could not capture image. Please ensure the webcam is working and try again.',
            });
            return;
        }
        const canvas = document.createElement('canvas');
        canvas.width = webcamRef.current.videoWidth;
        canvas.height = webcamRef.current.videoHeight;
        const context = canvas.getContext('2d');
        if (context) {
            context.drawImage(webcamRef.current, 0, 0, canvas.width, canvas.height);
            const dataUri = canvas.toDataURL('image/jpeg');
            setFaceDataUri(dataUri);
            toast({
                title: 'Face Captured!',
                description: 'Your facial data has been captured successfully.',
            });
        }
    }
  };
  
  async function onSubmit(values: z.infer<typeof registerFormSchema>) {
    if (!faceDataUri) {
        toast({
            variant: 'destructive',
            title: 'No Face Data',
            description: 'Please capture your face before registering.',
        });
        return;
    }
    
    setIsLoading(true);
    
    try {
        await registerUser({ ...values, faceDataUri });
        toast({
            title: 'Registration Successful!',
            description: 'You can now log in with your face.',
        });
        router.push('/face-login');
    } catch (error: any) {
        console.error(error);
        toast({
            variant: 'destructive',
            title: 'Registration Failed',
            description: error.message || 'An unexpected error occurred.',
        });
    } finally {
        setIsLoading(false);
    }
  }

  return (
    <PublicLayout>
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-2xl font-headline">Register New Face</CardTitle>
          <CardDescription>Complete your profile and capture your facial data for secure access.</CardDescription>
        </CardHeader>
        
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
                <CardContent className="space-y-6">
                    <div className="space-y-4">
                        <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Full Name</FormLabel>
                                <FormControl>
                                    <Input placeholder="John Doe" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="email"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Email</FormLabel>
                                <FormControl>
                                    <Input type="email" placeholder="john.doe@example.com" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name="password"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Password</FormLabel>
                                <FormControl>
                                    <Input type="password" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                    </div>
                  
                  <div>
                    <Label>Facial Scan</Label>
                     <WebcamFeed ref={webcamRef} />
                     <Button variant="secondary" className="w-full mt-4" type="button" onClick={handleCaptureFace}>
                      <Camera className="mr-2 h-4 w-4" />
                      Capture & Save Face
                    </Button>
                    {faceDataUri && (
                        <Alert variant="default" className="mt-4">
                            <CheckCircle className="h-4 w-4" />
                            <AlertTitle>Face Captured</AlertTitle>
                            <AlertDescription>
                                Your face data is ready for registration.
                            </AlertDescription>
                        </Alert>
                    )}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full" size="lg" type="submit" disabled={isLoading}>
                    {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UserPlus className="mr-2 h-4 w-4" />}
                    {isLoading ? 'Registering...' : 'Register'}
                  </Button>
                </CardFooter>
            </form>
        </Form>
       
      </Card>
    </PublicLayout>
  );
}
