import AuthLayout from '@/components/auth-layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { ScanFace, Lock, Trash2, LogOut } from 'lucide-react';
import Link from 'next/link';

export default function SettingsPage() {
  return (
    <AuthLayout>
      <div className="space-y-8 max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Update Face Encoding</CardTitle>
            <CardDescription>Re-capture your facial data to improve recognition accuracy.</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              If you've changed your appearance (e.g., new glasses, different hairstyle), updating your face encoding is recommended.
            </p>
          </CardContent>
          <CardFooter>
            <Button>
              <ScanFace className="mr-2 h-4 w-4" />
              Start Re-Capture
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Change Password</CardTitle>
            <CardDescription>Update your account password.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="current-password">Current Password</Label>
              <Input id="current-password" type="password" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-password">New Password</Label>
              <Input id="new-password" type="password" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirm-new-password">Confirm New Password</Label>
              <Input id="confirm-new-password" type="password" />
            </div>
          </CardContent>
          <CardFooter>
            <Button>
              <Lock className="mr-2 h-4 w-4" />
              Update Password
            </Button>
          </CardFooter>
        </Card>

        <Card className="border-destructive">
          <CardHeader>
            <CardTitle className="text-destructive">Account Management</CardTitle>
            <CardDescription>Manage your account settings and data.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
                <div>
                    <h3 className="font-semibold">Delete Account</h3>
                    <p className="text-sm text-muted-foreground">Permanently delete your account and all associated data. This action cannot be undone.</p>
                </div>
                 <Button variant="destructive">
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete Account
                </Button>
            </div>
            <Separator />
            <div className="flex justify-between items-center">
                 <div>
                    <h3 className="font-semibold">Logout</h3>
                    <p className="text-sm text-muted-foreground">Sign out from your current session.</p>
                </div>
                <Button variant="outline" asChild>
                    <Link href="/">
                        <LogOut className="mr-2 h-4 w-4" />
                        Logout
                    </Link>
                </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </AuthLayout>
  );
}
