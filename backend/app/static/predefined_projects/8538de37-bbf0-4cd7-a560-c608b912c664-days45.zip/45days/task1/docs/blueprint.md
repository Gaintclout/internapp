# **App Name**: Identiq Vision

## Core Features:

- Landing Page: Landing page with login, registration, and admin panel entry points.
- Face Registration: Face registration with webcam capture and data input.
- Face Login: Real-time face recognition via webcam for login, with match/fake attempt detection.
- Inbox Page: Display of recent emails in a table format with read/logout actions.
- Alert Page: Display of intrusion warning with IP address, location, and face snapshot (if available).
- Login History: Table of login history with filters (date, time, name, status, IP, emotion).
- Admin Panel: Admin panel to manage users, fake attempts, and access stats.

## Style Guidelines:

- Primary color: Deep blue (#3F51B5) to evoke trust and security.
- Background color: Very dark blue (#283593) for a high-tech feel and to emphasize contrast.
- Accent color: Teal (#009688) for highlights and interactive elements, offering a modern and fresh look.
- Font pairing: 'Space Grotesk' (sans-serif) for headlines and 'Inter' (sans-serif) for body text.
- Code font: 'Source Code Pro' (monospace) for any code snippets.
- Use clear and minimalist icons relevant to face recognition and security.
- Modern, grid-based layout to organize data and interface elements effectively.