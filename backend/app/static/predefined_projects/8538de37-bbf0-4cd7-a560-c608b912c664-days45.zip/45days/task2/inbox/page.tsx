import AuthLayout from '@/components/auth-layout';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Eye, LogOut } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import Link from 'next/link';

const emails = [
  { id: 1, sender: 'Figma', subject: 'Password Reset', snippet: 'You requested a password reset...', time: '10:45 AM', read: false },
  { id: 2, sender: 'GitHub', subject: '[GitHub] A third-party OAuth application...', snippet: 'Hey user, A third-party OAuth application...', time: 'Yesterday', read: true },
  { id: 3, sender: 'Vercel', subject: 'Deployment Successful', snippet: 'Your project has been deployed successfully.', time: '2 days ago', read: true },
  { id: 4, sender: 'Stripe', subject: 'Your weekly summary', snippet: 'Here is your weekly transaction summary...', time: '3 days ago', read: false },
];

export default function InboxPage() {
  return (
    <AuthLayout>
        <div className="flex justify-end mb-4">
             <Button variant="outline" asChild>
                <Link href="/">
                <LogOut className="mr-2 h-4 w-4" />
                Logout
                </Link>
            </Button>
        </div>
      <Card>
        <CardHeader>
          <CardTitle>Recent Emails</CardTitle>
          <CardDescription>A list of your most recent emails.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Sender</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead className="hidden md:table-cell">Snippet</TableHead>
                <TableHead className="text-right">Time</TableHead>
                <TableHead className="text-center">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {emails.map((email) => (
                <TableRow key={email.id} className={!email.read ? 'font-bold bg-primary/5' : ''}>
                  <TableCell>{email.sender}</TableCell>
                  <TableCell>
                    {email.subject}
                    {!email.read && <Badge variant="default" className="ml-2">New</Badge>}
                  </TableCell>
                  <TableCell className="hidden md:table-cell max-w-sm truncate">{email.snippet}</TableCell>
                  <TableCell className="text-right">{email.time}</TableCell>
                  <TableCell className="text-center">
                    <Button variant="ghost" size="icon">
                      <Eye className="h-4 w-4" />
                      <span className="sr-only">Read Full Email</span>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </AuthLayout>
  );
}
