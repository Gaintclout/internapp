
'use client';

import { useState, useEffect, forwardRef, Ref } from 'react';
import { cn } from '@/lib/utils';
import { Video, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';

type WebcamFeedProps = {
  detectionStatus?: 'match' | 'mismatch' | 'neutral';
};

const WebcamFeed = forwardRef<HTMLVideoElement, WebcamFeedProps>(
  ({ detectionStatus = 'neutral' }, ref: Ref<HTMLVideoElement>) => {
    const { toast } = useToast();
    const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);

    useEffect(() => {
        const getCameraPermission = async () => {
          try {
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                throw new Error('Camera API not available in this browser.');
            }
            const stream = await navigator.mediaDevices.getUserMedia({ video: true });
            setHasCameraPermission(true);

            if (ref && 'current' in ref && ref.current) {
              ref.current.srcObject = stream;
            }
          } catch (error) {
            console.error('Error accessing camera:', error);
            setHasCameraPermission(false);
            toast({
              variant: 'destructive',
              title: 'Camera Access Denied',
              description: 'Please enable camera permissions in your browser settings to use this app.',
            });
          }
        };

        getCameraPermission();

        return () => {
            if (ref && 'current' in ref && ref.current && ref.current.srcObject) {
                const stream = ref.current.srcObject as MediaStream;
                stream.getTracks().forEach(track => track.stop());
            }
        }
    }, [ref, toast]);

    const borderColor = {
      match: 'border-green-500',
      mismatch: 'border-red-500',
      neutral: 'border-primary',
    };

    return (
      <div
        className={cn(
          'relative aspect-square w-full rounded-lg border-4 bg-muted/50 flex items-center justify-center transition-all duration-300 shadow-inner overflow-hidden',
          borderColor[detectionStatus]
        )}
      >
        <video ref={ref} className="w-full h-full object-cover" autoPlay muted playsInline />

        {hasCameraPermission === false && (
            <div className="absolute inset-0 bg-black/70 flex items-center justify-center z-10 p-4">
                 <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Camera Access Required</AlertTitle>
                    <AlertDescription>
                        Please allow camera access in your browser to use this feature. You might need to refresh the page after granting permission.
                    </AlertDescription>
                </Alert>
            </div>
        )}
         {hasCameraPermission === null && (
             <div className="absolute inset-0 bg-black/70 flex items-center justify-center z-10">
                <div className="text-center text-muted-foreground">
                    <Video className="mx-auto h-16 w-16 mb-2" />
                    <p className="font-semibold">Requesting Camera...</p>
                </div>
            </div>
        )}

        {detectionStatus === 'match' && (
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-green-500/90 text-white px-4 py-1 rounded-full text-sm font-semibold z-20">
            ✅ Match Found
          </div>
        )}
        {detectionStatus === 'mismatch' && (
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-red-500/90 text-white px-4 py-1 rounded-full text-sm font-semibold z-20">
            ❌ Mismatch or Fake
          </div>
        )}
      </div>
    );
  }
);
WebcamFeed.displayName = 'WebcamFeed';

export default WebcamFeed;
