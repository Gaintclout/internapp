'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
  SidebarTrigger,
  SidebarInset,
} from '@/components/ui/sidebar';
import {
  Mail,
  History,
  ShieldAlert,
  Users,
  Settings,
  LogOut,
  ScanFace,
  LayoutDashboard,
} from 'lucide-react';
import Logo from './logo';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { Button } from './ui/button';
import { useAppState } from '@/hooks/use-app-state';

const menuItems = [
  { href: '/inbox', label: 'Inbox', icon: Mail },
  { href: '/history', label: 'Login History', icon: History },
  { href: '/alert', label: 'Alerts', icon: ShieldAlert },
  { href: '/admin', label: 'Admin Panel', icon: Users },
  { href: '/settings', label: 'Settings', icon: Settings },
];

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { user, setUser } = useAppState();

  const handleLogout = () => {
    setUser(null);
  }

  if (!user) {
    if (typeof window !== 'undefined') {
        const { useRouter } = require('next/navigation');
        const router = useRouter();
        router.push('/face-login');
    }
    return null;
  }

  return (
    <SidebarProvider>
      <Sidebar>
        <SidebarHeader>
          <Logo />
        </SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            {menuItems.map((item) => (
              <SidebarMenuItem key={item.href}>
                <Link href={item.href}>
                  <SidebarMenuButton isActive={pathname === item.href} tooltip={item.label}>
                    <item.icon />
                    <span>{item.label}</span>
                  </SidebarMenuButton>
                </Link>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarContent>
        <SidebarFooter>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
               <button className="flex items-center gap-3 w-full p-2 rounded-md hover:bg-sidebar-accent">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.faceDataUri} alt={user.name} />
                  <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="text-left group-data-[collapsible=icon]:hidden">
                  <p className="font-semibold text-sm">{user.name}</p>
                  <p className="text-xs text-muted-foreground">{user.email}</p>
                </div>
               </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent side="right" align="start" className="w-56">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild><Link href="/settings"><Settings className="mr-2 h-4 w-4"/>Settings</Link></DropdownMenuItem>
                <DropdownMenuItem asChild><Link href="/" onClick={handleLogout}><LogOut className="mr-2 h-4 w-4"/>Log out</Link></DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </SidebarFooter>
      </Sidebar>
      <SidebarInset>
        <header className="flex items-center justify-between p-4 border-b">
           <SidebarTrigger />
           <h1 className="text-xl font-semibold font-headline">
            {menuItems.find(item => pathname.startsWith(item.href))?.label || 'Dashboard'}
           </h1>
           <div />
        </header>
        <main className="flex-1 p-4 md:p-6 overflow-y-auto">
          {children}
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
