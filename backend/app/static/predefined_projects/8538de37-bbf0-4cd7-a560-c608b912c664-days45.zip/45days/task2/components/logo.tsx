import { ScanFace } from 'lucide-react';
import { cn } from '@/lib/utils';

type LogoProps = {
  className?: string;
};

export default function Logo({ className }: LogoProps) {
  return (
    <div className={cn('flex items-center gap-2', className)}>
      <ScanFace className="h-8 w-8 text-primary" />
      <span className="text-2xl font-bold font-headline">Identiq Vision</span>
    </div>
  );
}
