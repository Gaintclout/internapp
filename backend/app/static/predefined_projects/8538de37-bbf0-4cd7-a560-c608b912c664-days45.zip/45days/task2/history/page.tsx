'use client';
import AuthLayout from '@/components/auth-layout';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Download, Filter, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useAppState } from '@/hooks/use-app-state';
import { format } from 'date-fns';

export default function HistoryPage() {
    const { attempts } = useAppState();

    const getStatus = (attempt: any) => {
        if (attempt.found) return { variant: 'secondary', icon: <CheckCircle className="text-green-500"/>, label: 'Success' };
        if (!attempt.analysis?.isReal) return { variant: 'destructive', icon: <AlertTriangle className="text-yellow-500" />, label: 'Fake Attempt' };
        return { variant: 'destructive', icon: <XCircle className="text-red-500" />, label: 'Failed' };
    };

  return (
    <AuthLayout>
      <Card>
        <CardHeader>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <CardTitle>Login History</CardTitle>
                    <CardDescription>Review all login attempts to your account.</CardDescription>
                </div>
                <div className="flex gap-2">
                    <Input placeholder="Filter..." className="w-auto" />
                    <Button variant="outline">
                        <Filter className="mr-2 h-4 w-4" />
                        Filters
                    </Button>
                    <Button>
                        <Download className="mr-2 h-4 w-4" />
                        Download CSV
                    </Button>
                </div>
            </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date & Time</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Emotion</TableHead>
                <TableHead>Liveness Confidence</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {attempts.map((entry, index) => {
                  const status = getStatus(entry);
                  return (
                    <TableRow key={index}>
                      <TableCell>{format(new Date(), 'PPpp')}</TableCell>
                      <TableCell>{entry.user?.name || 'Unknown'}</TableCell>
                      <TableCell>
                        <Badge variant={status.variant as any} className="flex items-center gap-2">
                          {status.icon}
                          <span>{status.label}</span>
                        </Badge>
                      </TableCell>
                      <TableCell>{entry.analysis?.emotion}</TableCell>
                      <TableCell>
                        <Badge variant={entry.analysis?.isReal ? 'secondary' : 'destructive'}>
                            {((entry.analysis?.livenessConfidence ?? 0) * 100).toFixed(0)}%
                        </Badge>
                      </TableCell>
                    </TableRow>
                )
            })}
             {attempts.length === 0 && (
                <TableRow>
                    <TableCell colSpan={5} className="text-center h-24">No login history yet.</TableCell>
                </TableRow>
            )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </AuthLayout>
  );
}
