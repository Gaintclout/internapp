import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { ArrowRight, LogIn, UserPlus, Shield } from 'lucide-react';
import Logo from '@/components/logo';

export default function Home() {
  return (
    <div className="relative min-h-screen w-full bg-background">
      <div className="absolute inset-0 bg-grid-slate-700/[0.04] bg-[bottom_1px_center] dark:bg-grid-slate-400/[0.05]" style={{ maskImage: 'linear-gradient(to_bottom, transparent, black, transparent)' }}></div>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-4 text-center">
        <header className="mb-8">
          <Logo />
        </header>
        
        <main className="flex flex-col items-center">
          <h1 className="text-4xl md:text-6xl font-bold font-headline mb-4 bg-gradient-to-r from-primary via-blue-400 to-accent bg-clip-text text-transparent">
            Welcome to Secure Face
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mb-12">
            The future of authentication is here. Experience seamless and secure access with our AI-powered face login system.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Button asChild size="lg" className="font-semibold">
              <Link href="/face-login">
                <LogIn className="mr-2 h-5 w-5" />
                Login with Face
              </Link>
            </Button>
            <Button asChild size="lg" variant="secondary" className="font-semibold">
              <Link href="/register-face">
                <UserPlus className="mr-2 h-5 w-5" />
                Register New Face
              </Link>
            </Button>
            <Button asChild size="lg"  className="font-semibold">
              <Link href="/admin">
                <Shield className="mr-2 h-5 w-5" />
                Admin Panel
              </Link>
            </Button>
          </div>
        </main>

        <footer className="absolute bottom-4 text-sm text-muted-foreground">
          © {new Date().getFullYear()} Identiq Vision. All rights reserved.
        </footer>
      </div>
    </div>
  );
}
