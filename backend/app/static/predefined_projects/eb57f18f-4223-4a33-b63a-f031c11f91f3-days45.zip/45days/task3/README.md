Task3: Integration + Requirements + Deployment
