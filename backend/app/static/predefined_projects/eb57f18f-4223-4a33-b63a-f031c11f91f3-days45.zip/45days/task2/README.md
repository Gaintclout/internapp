Task2: Backend app.py
