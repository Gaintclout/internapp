Task1: Frontend UI (templates + static)
