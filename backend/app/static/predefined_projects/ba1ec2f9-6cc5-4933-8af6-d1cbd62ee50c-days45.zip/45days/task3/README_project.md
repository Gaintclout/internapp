# Siri-like macOS Voice Assistant

## Features
- Voice & text command support
- Opens macOS apps
- Google search integration
- Speaks responses using pyttsx3
- React-based frontend
- FastAPI backend

## Setup Instructions

### Backend
```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload
```

### Frontend
```bash
cd frontend
npx create-react-app .
npm install
npm start
```

## Usage
- Start backend → http://127.0.0.1:8000
- Start frontend → http://localhost:3000
- Enter commands like:
  - `open safari`
  - `search python fastapi`
  - `what time is it`
  - `what's the date`
  - `quit`
