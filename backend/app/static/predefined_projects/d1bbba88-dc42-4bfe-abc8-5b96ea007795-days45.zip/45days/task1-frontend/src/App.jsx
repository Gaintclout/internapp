import { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom';
import './styles.css';
import MovieDetails from './MovieDetails';

function MovieCard({ movie, isLiked, onLikeToggle }) {
  return (
    <div className="movie-card">
      <Link to={`/movie/${movie.id}`} className="movie-link">
        <div className="movie-thumbnail">
          <img 
            src={movie.thumbnail || 'https://via.placeholder.com/300x450?text=No+Poster+Available'}
            alt={`${movie.title} poster`}
            onError={(e) => {
              e.target.onerror = null;
              e.target.src = 'https://via.placeholder.com/300x450?text=No+Poster+Available';
            }}
          />
          <div className="movie-rating" style={{ backgroundColor: getRatingColor(movie.rating) }}>
            {movie.rating?.toFixed(1) || 'N/A'}
          </div>
        </div>
        <div className="movie-content">
          <h3 className="movie-title">{movie.title}</h3>
          <div className="movie-meta">
            <span>{movie.year}</span>
            <span>•</span>
            <span className="language-tag">{movie.language}</span>
          </div>
        </div>
      </Link>
      <button 
        className={`like-button ${isLiked ? 'liked' : ''}`}
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          onLikeToggle(movie, isLiked);
        }}
        aria-label={isLiked ? 'Remove from liked' : 'Add to liked'}
      >
        {isLiked ? '❤️' : '🤍'}
      </button>
    </div>
  );
}

function App() {
  const [movies, setMovies] = useState([]);
  const [liked, setLiked] = useState([]);
  const [tab, setTab] = useState('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const baseUrl = import.meta.env.VITE_API_BASE || 'http://localhost:8000';
        const res = await fetch(`${baseUrl}/api/movies`);
        const data = await res.json();
        setMovies(data);
      } catch (err) {
        setError('Failed to fetch movies');
        console.error('Error:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchMovies();
  }, []);

  const handleLikeToggle = (movie, isLiked) => {
    if (isLiked) {
      setLiked(prev => prev.filter(m => m.id !== movie.id));
    } else {
      setLiked(prev => [...prev, movie]);
    }
  };

  const getFilteredMovies = () => {
    if (tab === 'liked') {
      return movies.filter(movie => liked.some(m => m.id === movie.id));
    }
    return movies;
  };

  if (loading) {
    return <div className="loading">Loading movies...</div>;
  }

  if (error) {
    return <div className="error">{error}</div>;
  }

  return (
    <div className="container">
      <h2>🎬 Movie Recommendation System</h2>
      
      <div className="tabs">
        <button 
          className={`tab ${tab === 'all' ? 'active' : ''}`}
          onClick={() => setTab('all')}
        >
          All Movies
        </button>
        <button 
          className={`tab ${tab === 'liked' ? 'active' : ''}`}
          onClick={() => setTab('liked')}
        >
          Liked Movies ({liked.length})
        </button>
      </div>

      <div className="movies-grid">
        {getFilteredMovies().map(movie => (
          <MovieCard
            key={movie.id}
            movie={movie}
            isLiked={liked.some(m => m.id === movie.id)}
            onLikeToggle={handleLikeToggle}
          />
        ))}
      </div>
    </div>
  );
}

// Helper function to get rating color
function getRatingColor(rating) {
  if (rating >= 8.5) return '#4CAF50';
  if (rating >= 7.5) return '#8BC34A';
  if (rating >= 6.5) return '#FFC107';
  if (rating >= 5.5) return '#FF9800';
  return '#F44336';
}

// Main App with Router
function AppWithRouter() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<App />} />
        <Route path="/movie/:id" element={<MovieDetails />} />
      </Routes>
    </Router>
  );
}

export default AppWithRouter;
