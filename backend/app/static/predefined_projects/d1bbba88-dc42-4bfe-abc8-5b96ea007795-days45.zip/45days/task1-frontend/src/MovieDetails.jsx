import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

function MovieDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [movie, setMovie] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showTrailer, setShowTrailer] = useState(false);
  const [trailerKey, setTrailerKey] = useState('');

  // YouTube trailer search terms mapping
  const trailerSearchTerms = {
    1: 'Inception official trailer',
    2: 'Parasite official trailer',
    3: 'The Dark Knight official trailer',
    4: 'Your Name official trailer',
    5: 'The Intouchables official trailer',
    6: 'RRR official trailer',
    7: 'The Platform official trailer',
    8: 'Train to Busan official trailer'
  };

  useEffect(() => {
    const fetchMovieDetails = async () => {
      try {
        const baseUrl = import.meta.env.VITE_API_BASE || 'http://localhost:8000';
        const response = await fetch(`${baseUrl}/api/movies`);
        const movies = await response.json();
        const foundMovie = movies.find(m => m.id === parseInt(id));
        
        if (foundMovie) {
          setMovie(foundMovie);
          // Set a default trailer key based on movie ID
          const trailerKeys = {
            1: 'YoHD9XEInc0', // Inception
            2: '5xH0HfJHsaY', // Parasite
            3: 'EXeTwQWrcwY', // The Dark Knight
            4: 'xU47nhruN-Q', // Your Name
            5: '34WIbmXkewU', // The Intouchables
            6: '2_BkCz3OnlY', // RRR
            7: 'RlfooqeZcdY', // The Platform
            8: 'pyWuHv2-Abk'  // Train to Busan
          };
          setTrailerKey(trailerKeys[foundMovie.id] || '');
        } else {
          setError('Movie not found');
        }
      } catch (err) {
        setError('Failed to fetch movie details');
        console.error('Error:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchMovieDetails();
  }, [id]);

  const handleImageError = (e) => {
    e.target.onerror = null;
    e.target.src = 'https://via.placeholder.com/500x750?text=No+Poster+Available';
  };

  const toggleTrailer = () => {
    setShowTrailer(!showTrailer);
  };

  if (loading) {
    return (
      <div className="movie-details-loading">
        <div className="loading-spinner"></div>
        <p>Loading movie details...</p>
      </div>
    );
  }

  if (error || !movie) {
    return (
      <div className="movie-details-error">
        <h2>{error || 'Movie not found'}</h2>
        <button onClick={() => navigate('/')} className="back-button">
          Back to Movies
        </button>
      </div>
    );
  }

  return (
    <div className="movie-details-container">
      <button onClick={() => navigate(-1)} className="back-button">
         Back to Movies
      </button>
      
      <div className="movie-details">
        <div className="movie-poster">
          <img 
            src={movie.thumbnail || 'https://via.placeholder.com/500x750?text=No+Poster+Available'} 
            alt={`${movie.title} poster`}
            onError={handleImageError}
          />
        </div>
        
        <div className="movie-info">
          <h1>{movie.title} <span className="year">({movie.year})</span></h1>
          
          <div className="movie-meta">
            <span className="rating" style={{ 
              backgroundColor: getRatingColor(movie.rating),
              color: movie.rating >= 7 ? 'white' : 'black'
            }}>
              {movie.rating?.toFixed(1) || 'N/A'}
            </span>
            <span className="language">{movie.language}</span>
            <span className="genres">{movie.genres}</span>
          </div>
          
          <div className="movie-description">
            <h3>Overview</h3>
            <p>{movie.description || 'No description available.'}</p>
          </div>
          
          <div className="movie-actions">
            {trailerKey && (
              <button className="watch-trailer" onClick={toggleTrailer}>
                {showTrailer ? 'Hid e Trailer' : '▶ Watch Trailer'}
              </button>
            )}
          </div>

          {showTrailer && trailerKey && (
            <div className="trailer-container">
              <div className="trailer-embed">
                <iframe
                  width="100%"
                  height="400"
                  src={`https://www.youtube.com/embed/${trailerKey}?autoplay=1`}
                  title={`${movie.title} Trailer`}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen>
                </iframe>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Helper function to get rating color
function getRatingColor(rating) {
  if (rating >= 8.5) return '#4CAF50';
  if (rating >= 7.5) return '#8BC34A';
  if (rating >= 6.5) return '#FFC107';
  if (rating >= 5.5) return '#FF9800';
  return '#F44336';
}

export default MovieDetails;
