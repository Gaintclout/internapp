from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import random

app = Flask(__name__, static_folder='static')
CORS(app)

# Create static directory if it doesn't exist
os.makedirs('static/thumbnails', exist_ok=True)

# Enhanced movie data with more reliable image sources
MOVIES = [
    {
        'id': 1, 
        'title': 'Inception', 
        'genres': 'Action Sci-Fi', 
        'year': 2010,
        'language': 'English',
        'thumbnail': 'https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_.jpg',
        'rating': 8.8,
        'description': 'A thief who steals corporate secrets through the use of dream-sharing technology.'
    },
    {
        'id': 2, 
        'title': 'Parasite', 
        'genres': 'Drama Thriller', 
        'year': 2019,
        'language': 'Korean',
        'thumbnail': 'https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcRa9QXcKkW6fhivLE4LjAdeC7CvLFnJk5vRjkK7siVD5TkeXVfU',
        'rating': 8.6,
        'description': 'Greed and class discrimination threaten the relationship between the wealthy Park family and the destitute Kim clan.'
    },
    {
        'id': 3, 
        'title': 'The Dark Knight', 
        'genres': 'Action Crime Drama', 
        'year': 2008,
        'language': 'English',
        'thumbnail': 'https://m.media-amazon.com/images/M/MV5BMTMxNTMwODM0NF5BMl5BanBnXkFtZTcwODAyMTk2Mw@@._V1_.jpg',
        'rating': 9.0,
        'description': 'When the menace known as the Joker wreaks havoc and chaos on the people of Gotham.'
    },
    {
        'id': 4, 
        'title': 'Your Name', 
        'genres': 'Animation Drama Fantasy', 
        'year': 2016,
        'language': 'Japanese',
        'thumbnail': 'https://m.media-amazon.com/images/M/MV5BNGYyNmI3M2YtNzYzZS00OTViLTkxYjAtZDIyZmE1Y2U1ZmQ2XkEyXkFqcGdeQXVyMTA4NjE0NjEy._V1_.jpg',
        'rating': 8.4,
        'description': 'Two strangers find themselves linked in a bizarre way. When a connection forms, will distance be the only thing to keep them apart?'
    },
    {
        'id': 5, 
        'title': 'The Intouchables', 
        'genres': 'Biography Comedy Drama', 
        'year': 2011,
        'language': 'French',
        'thumbnail': 'https://m.media-amazon.com/images/M/MV5BMTYxNDA3MDQwNl5BMl5BanBnXkFtZTcwNTU4Mzc1Nw@@._V1_.jpg',
        'rating': 8.5,
        'description': 'After he becomes a quadriplegic, an aristocrat hires a young man from the projects to be his caregiver.'
    },
    {
        'id': 6, 
        'title': 'RRR', 
        'genres': 'Action Drama', 
        'year': 2022,
        'language': 'Telugu',
        'thumbnail': 'https://m.media-amazon.com/images/M/MV5BODUwNDNjYzctODUxNy00ZTA2LWIyYTEtMDc5Y2E5ZjBmNTMzXkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_.jpg',
        'rating': 8.0,
        'description': 'A fictitious story about two legendary revolutionaries and their journey away from home before they started fighting for their country.'
    },
    {
        'id': 7, 
        'title': 'The Platform', 
        'genres': 'Horror Sci-Fi Thriller', 
        'year': 2019,
        'language': 'Spanish',
        'thumbnail': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0-D4ZhR8rpZicuVUdB8eJpEes-cylpjUPp0Lw7T3FPG56s-P6',
        'rating': 7.0,
        'description': 'A vertical prison with one cell per level. Two people per cell. Only one food platform and two minutes per day to feed.'
    },
    {
        'id': 8, 
        'title': 'Train to Busan', 
        'genres': 'Action Horror Thriller', 
        'year': 2016,
        'language': 'Korean',
        'thumbnail': 'https://m.media-amazon.com/images/M/MV5BMTkwOTQ4OTg0OV5BMl5BanBnXkFtZTgwMzQyOTM0OTE@._V1_.jpg',
        'rating': 7.6,
        'description': 'While a zombie virus breaks out in South Korea, passengers struggle to survive on the train from Seoul to Busan.'
    }
]

@app.get('/api/health')
def health():
    return jsonify({'status':'ok'})

@app.get('/api/movies')
def list_movies():
    return jsonify(MOVIES)

@app.get('/api/thumbnails/<path:filename>')
def serve_thumbnail(filename):
    return send_from_directory('static/thumbnails', filename)

@app.get('/api/recommend/content')
def content():
    # naive content-based: return movies with same language as the given movie_id
    movie_id = int(request.args.get('movie_id', 1))
    base = next((m for m in MOVIES if m['id']==movie_id), MOVIES[0])
    language = base.get('language', '')
    recs = [m for m in MOVIES if m.get('language') == language and m['id'] != movie_id]
    return jsonify(recs)

@app.get('/api/recommend/cf')
def cf():
    # naive collaborative: return top rated movies
    k = int(request.args.get('k', 5))
    return jsonify(sorted(MOVIES, key=lambda x: x['rating'], reverse=True)[:k])

@app.post('/api/recommend/hybrid')
def hybrid():
    data = request.get_json(silent=True) or {}
    
    if not data:
        return jsonify(sorted(MOVIES, key=lambda x: x['rating'], reverse=True)[:5])
    
    liked = data.get('liked_movie_ids', [])
    
    if not liked:
        return jsonify(sorted(MOVIES, key=lambda x: x['rating'], reverse=True)[:5])
    
    # Get language preferences from liked movies
    liked_movies = [m for m in MOVIES if m['id'] in liked]
    languages = [m['language'] for m in liked_movies]
    
    # Recommend similar language movies with good ratings
    recs = [m for m in MOVIES 
            if m['id'] not in liked 
            and m['language'] in languages 
            and m['rating'] >= 7.0]
    
    # If not enough recs, add top rated movies
    if len(recs) < 5:
        top_rated = [m for m in MOVIES if m['id'] not in liked and m['rating'] >= 7.0]
        recs.extend(top_rated[:5 - len(recs)])
    
    return jsonify(recs[:5])

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)
