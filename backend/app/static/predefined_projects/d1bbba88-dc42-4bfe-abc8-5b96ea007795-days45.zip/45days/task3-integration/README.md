# Movie Recommendation System (Minimal)
This archive contains a minimal end-to-end skeleton for a Movie Recommendation System:
- backend: Flask API (simple endpoints)
- frontend: Vite + React minimal app that calls backend
- docker-compose.yml and .env.example for quick local setup

**How to run (local, minimal):**
1. Backend: `cd backend && python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt && python app.py`
2. Frontend: `cd frontend && npm install && npm run dev` (Vite default port 5173)
3. Alternatively, use Docker Compose (requires Docker): `docker compose up --build`
