# task2
Semester task split.
