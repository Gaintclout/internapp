# task5
Semester task split.
