# task3
Semester task split.
