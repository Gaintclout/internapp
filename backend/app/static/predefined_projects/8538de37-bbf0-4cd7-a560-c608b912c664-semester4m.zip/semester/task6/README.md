# task6
Semester task split.
