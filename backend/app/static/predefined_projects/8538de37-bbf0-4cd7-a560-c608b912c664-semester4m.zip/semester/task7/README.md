# task7
Semester task split.
