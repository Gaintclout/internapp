# **App Name**: ResumeRank

## Core Features:

- Applicant Form: Applicant form with fields for Name, Email, and Resume upload.
- Application Submission: Submit button that stores applicant data locally (using browser local storage or a similar method) and triggers an email notification to the admin.
- Admin Dashboard: Admin table displaying applicant Name, Skills Match, Shortlist/Reject option, Resume link, and Mail icon.
- Skills Matcher: AI tool that uses the uploaded resume content to determine the matching skills compared to those requested in a predefined list and displays the degree of match in the 'Skills Match' column.
- Applicant List: Shortlist/Reject selection displayed on the dashboard.
- Resume Link: A link that will open the resume pdf in the dashboard
- Mail Applicant: Clicking the mail icon should trigger a mail action to a selected user using a local mail application.

## Style Guidelines:

- Primary color: Soft blue (#77B5FE) to convey trustworthiness and professionalism, without being too corporate.
- Background color: Light grey (#F0F4F8) for a clean, modern feel in a light color scheme.
- Accent color: Soft violet (#B19CD9) to add a touch of creativity and highlight interactive elements.
- Font pairing: 'Inter' for body text (sans-serif) combined with 'Literata' for headlines (serif), to balance legibility with a touch of vintage elegance.
- Simple, outlined icons for actions (e.g., mail, resume download) and status indicators (e.g., shortlist, reject).
- Clean, responsive layout with clear visual hierarchy and sufficient whitespace to avoid clutter.
- Subtle transitions and animations for feedback on user interactions (e.g., button hover effects, loading states).